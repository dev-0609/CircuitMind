"""Deterministic theoretical-vs-simulation checks for CircuitMind's supported RC step response.

This module verifies only the ideal first-order RC charging model represented by the
current RC netlist generator. It is not a general circuit safety checker.
"""
from __future__ import annotations

import math
from typing import Sequence


def theoretical_rc_voltage(time_s: float, vin: float, resistance_ohm: float, capacitance_f: float) -> float:
    """Ideal capacitor voltage for a 0 V capacitor driven by a sustained voltage step."""
    if time_s < 0:
        raise ValueError("time_s must be non-negative")
    if vin <= 0 or resistance_ohm <= 0 or capacitance_f <= 0:
        raise ValueError("vin, resistance and capacitance must be positive")
    tau = resistance_ohm * capacitance_f
    return vin * (1.0 - math.exp(-time_s / tau))


def _interpolate(times: Sequence[float], values: Sequence[float], target: float) -> float:
    if len(times) != len(values) or len(times) < 2:
        raise ValueError("At least two matching time/voltage samples are required")
    if target <= times[0]:
        return float(values[0])
    if target >= times[-1]:
        return float(values[-1])
    lo, hi = 0, len(times) - 1
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if times[mid] <= target:
            lo = mid
        else:
            hi = mid
    dt = times[hi] - times[lo]
    if dt <= 0:
        raise ValueError("Simulation times must be strictly increasing")
    fraction = (target - times[lo]) / dt
    return float(values[lo]) + fraction * (float(values[hi]) - float(values[lo]))


def verify_rc_step_response(
    times_s: Sequence[float],
    voltages_v: Sequence[float],
    vin: float,
    resistance_ohm: float,
    capacitance_f: float,
    *,
    tolerance_v: float | None = None,
) -> dict:
    """Compare ngspice samples to theory and report a bounded PASS/FAIL result.

    Default tolerance accounts for a finite, short source rise time and simulator
    sampling. It is max(50 mV, 2% of input voltage); this is a demo acceptance
    threshold, not a safety certification.
    """
    if len(times_s) != len(voltages_v) or len(times_s) < 2:
        raise ValueError("Simulation must provide at least two matching time/voltage samples")
    times = [float(t) for t in times_s]
    volts = [float(v) for v in voltages_v]
    if any(not math.isfinite(x) for x in times + volts):
        raise ValueError("Simulation samples must be finite numbers")
    if any(times[i + 1] <= times[i] for i in range(len(times) - 1)):
        raise ValueError("Simulation times must be strictly increasing")
    if vin <= 0 or resistance_ohm <= 0 or capacitance_f <= 0:
        raise ValueError("vin, resistance and capacitance must be positive")

    tau = resistance_ohm * capacitance_f
    tolerance = float(tolerance_v if tolerance_v is not None else max(0.05, 0.02 * vin))
    comparison_times = [min(times[-1], factor * tau) for factor in (0.5, 1.0, 2.0)]
    rows = []
    for t in comparison_times:
        actual = _interpolate(times, volts, t)
        expected = theoretical_rc_voltage(t, vin, resistance_ohm, capacitance_f)
        error = actual - expected
        rows.append({
            "time_s": t,
            "time_ms": t * 1000.0,
            "expected_v": expected,
            "simulated_v": actual,
            "error_v": error,
            "absolute_error_v": abs(error),
            "status": "PASS" if abs(error) <= tolerance else "FAIL",
        })

    theoretical_curve = [theoretical_rc_voltage(t, vin, resistance_ohm, capacitance_f) for t in times]
    max_abs_error = max(abs(actual - expected) for actual, expected in zip(volts, theoretical_curve))
    monotonic = all(volts[i + 1] >= volts[i] - 1e-6 for i in range(len(volts) - 1))
    final_expected = theoretical_rc_voltage(times[-1], vin, resistance_ohm, capacitance_f)
    passed = max_abs_error <= tolerance and monotonic
    return {
        "status": "PASS" if passed else "FAIL",
        "passed": passed,
        "tolerance_v": tolerance,
        "max_absolute_error_v": max_abs_error,
        "monotonic_rise": monotonic,
        "final_expected_v": final_expected,
        "final_simulated_v": volts[-1],
        "tau_s": tau,
        "sample_checks": rows,
        "theoretical_curve_v": theoretical_curve,
        "scope_note": "Checks an ideal RC charging model against the sampled simulator output; not a general electrical safety certification.",
    }
