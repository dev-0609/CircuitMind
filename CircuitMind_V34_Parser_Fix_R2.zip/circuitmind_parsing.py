"""Deterministic parser for CircuitMind's supported passive RC topology.

Extracts explicit resistance, capacitance, and input step voltage from a prompt.
This intentionally supports one RC topology; it is not a general-purpose circuit parser.
"""
import re

_NUMBER = r"([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?)"

def _normalise(text: str) -> str:
    text = text.lower()
    text = (text.replace("µ", "u").replace("μ", "u")
                .replace("ω", "ohm").replace("Ω", "ohm"))
    # Normalize common written-out units, longest phrases first.
    replacements = [
        ("megaohms", "megohm"), ("megaohm", "megohm"),
        ("meg ohms", "megohm"), ("meg ohm", "megohm"),
        ("kilohms", "kohm"), ("kilohm", "kohm"),
        ("kilo ohms", "kohm"), ("kilo ohm", "kohm"),
        ("ohms", "ohm"),
        ("microfarads", "uf"), ("microfarad", "uf"),
        ("nanofarads", "nf"), ("nanofarad", "nf"),
        ("picofarads", "pf"), ("picofarad", "pf"),
        ("millifarads", "mf"), ("millifarad", "mf"),
        ("farads", "f"), ("farad", "f"),
        ("volts", "v"), ("volt", "v"),
    ]
    for old, new in replacements:
        text = text.replace(old, new)
    # Remove spaces within unit spellings but keep ordinary word boundaries.
    text = re.sub(r"(?<=\d)\s+(?=(?:meg\s*ohm|megohm|k\s*ohm|kohm|ohm|k|m\s*ohm|mohm|u\s*f|uf|n\s*f|nf|p\s*f|pf|m\s*f|mf|f|v)\b)", "", text)
    return re.sub(r"\s+", " ", text).strip()


def _extract_value(text: str, label: str, unit_pattern: str, scale_map: dict, default_unit: str):
    """Prefer a labeled R/C value; otherwise accept a number with an explicit unit."""
    labeled = re.search(
        rf"(?<![a-z0-9]){label}\s*(?:=|:|\bis\b|\bof\b)?\s*{_NUMBER}\s*({unit_pattern})?(?![a-z])",
        text,
    )
    match = labeled
    if not match:
        match = re.search(
            rf"(?<![a-z0-9.]){_NUMBER}\s*({unit_pattern})(?![a-z])",
            text,
        )
    noun = "resistance" if label == "r" else "capacitance"
    if not match:
        example = "R = 1 kOhm" if label == "r" else "C = 100 uF"
        raise ValueError(f"Couldn't identify {noun}. Include an explicit value, e.g. {example}.")
    value = float(match.group(1))
    unit = re.sub(r"\s+", "", (match.group(2) or default_unit)).lower()
    if unit not in scale_map:
        raise ValueError(f"Unsupported unit '{unit}' for {label.upper()}. Use supported engineering units.")
    if value <= 0:
        raise ValueError(f"{label.upper()} must be greater than zero.")
    return value * scale_map[unit]


def parse_rc_request(prompt: str, fallback_text: str = "") -> dict:
    """Return parsed SI values and capacitance in microfarads for the existing simulator.

    The user's original prompt is preferred. When an AI-generated structured design
    is available, fallback_text may supply explicit component values from that design.
    """
    if not isinstance(prompt, str) or not prompt.strip():
        raise ValueError("Describe an RC circuit and include resistance, capacitance, and step voltage.")
    # Some prompts describe the desired circuit without literal R/C notation, while
    # Gemini returns explicit values in the structured component proposal. Parse both
    # sources together so the simulation uses those stated values rather than failing
    # solely because the user's prose omitted an explicit resistance label.
    combined_text = prompt if not fallback_text.strip() else f"{prompt}\n{fallback_text}"
    text = _normalise(combined_text)
    r_units = r"(?:meg\s*ohm|megohm|mohm|k\s*ohm|kohm|ohm|meg|k)"
    c_units = r"(?:u\s*f|uf|n\s*f|nf|p\s*f|pf|m\s*f|mf|f)"
    r_scales = {"megohm": 1e6, "meg": 1e6, "mohm": 1e-3, "k": 1e3, "kohm": 1e3, "ohm": 1.0}
    c_scales = {"uf": 1e-6, "nf": 1e-9, "pf": 1e-12, "mf": 1e-3, "f": 1.0}
    r_ohm = _extract_value(text, "r", r_units, r_scales, "ohm")
    c_f = _extract_value(text, "c", c_units, c_scales, "uf")
    v_match = re.search(rf"(?<![a-z0-9.]){_NUMBER}\s*v(?:olt(?:s)?)?(?![a-z])", text)
    if not v_match:
        raise ValueError("Couldn't identify the step voltage. Include a value such as '5 V step input'.")
    vin = float(v_match.group(1))
    if not (0 < r_ohm <= 1e9 and 0 < c_f <= 1 and 0 < vin <= 1000):
        raise ValueError("Values are outside this prototype's supported range; use positive, practical R, C and voltage values.")
    return {"r_ohm": r_ohm, "c_f": c_f, "c_uf": c_f * 1e6, "vin": vin}
