"""Gemini-backed structured circuit proposal service. API keys stay server-side."""
import json
import os
import urllib.error
import urllib.request

DEFAULT_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.1-flash-lite")

SYSTEM_INSTRUCTION = """You are CircuitMind's engineering design proposal component. Return only valid JSON with this exact shape:
{
  "project_title": string,
  "summary": string,
  "components": [{"name": string, "quantity": integer, "value_or_model": string, "purpose": string}],
  "connections": [{"from": string, "to": string, "details": string}],
  "assumptions": [string],
  "validation_notes": [string]
}
Use practical, specific proposals. If required details are missing, state assumptions and flag them in validation_notes. Do not claim that a circuit has been simulated, built, compiled, or verified unless that actually happened. Mention relevant voltage/current/power/GPIO constraints and datasheet checks. For microcontroller projects, distinguish logic-level pins from power pins. Do not present unsafe mains wiring instructions. JSON only, no markdown fences."""


def _extract_json(text):
    text = (text or "").strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[-1]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()
    start, end = text.find("{"), text.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("The AI response did not contain a JSON object. Try a more specific request.")
    return json.loads(text[start:end + 1])


def validate_design(data):
    if not isinstance(data, dict):
        raise ValueError("Design response must be a JSON object.")
    required = ("project_title", "summary", "components", "connections", "assumptions", "validation_notes")
    for key in required:
        if key not in data:
            raise ValueError(f"AI response is missing required field: {key}")
    if not isinstance(data["components"], list) or not isinstance(data["connections"], list):
        raise ValueError("Components and connections must be lists.")
    if not isinstance(data["assumptions"], list) or not isinstance(data["validation_notes"], list):
        raise ValueError("Assumptions and validation_notes must be lists.")
    if len(data["components"]) > 80 or len(data["connections"]) > 160:
        raise ValueError("AI response exceeds the allowed design size.")
    for item in data["components"]:
        if not isinstance(item, dict) or not all(k in item for k in ("name", "quantity", "value_or_model", "purpose")):
            raise ValueError("A component entry is missing required fields.")
        try:
            item["quantity"] = max(1, min(999, int(item["quantity"])))
        except (TypeError, ValueError):
            item["quantity"] = 1
    for item in data["connections"]:
        if not isinstance(item, dict) or not all(k in item for k in ("from", "to", "details")):
            raise ValueError("A connection entry is missing required fields.")
    return data


def generate_design(prompt: str) -> dict:
    api_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured on the backend.")
    if not prompt or len(prompt.strip()) < 8:
        raise ValueError("Please describe the circuit in at least a few words.")
    if len(prompt) > 8000:
        raise ValueError("Prompt is too long; keep it under 8000 characters.")
    model = os.environ.get("GEMINI_MODEL", DEFAULT_MODEL).strip()
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
    body = {
        "systemInstruction": {"parts": [{"text": SYSTEM_INSTRUCTION}]},
        "contents": [{"role": "user", "parts": [{"text": prompt.strip()}]}],
        "generationConfig": {"temperature": 0.2, "responseMimeType": "application/json"},
    }
    request = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=45) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:1200]
        if exc.code in (400, 401, 403):
            raise RuntimeError(f"Gemini rejected the request or API key (HTTP {exc.code}). Check the key, API access, and model name. {detail}") from exc
        if exc.code == 429:
            raise RuntimeError("Gemini quota/rate limit reached. Check AI Studio quotas and try again later.") from exc
        raise RuntimeError(f"Gemini request failed (HTTP {exc.code}): {detail}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not reach Gemini: {exc.reason}") from exc
    try:
        response_text = payload["candidates"][0]["content"]["parts"][0]["text"]
    except (KeyError, IndexError, TypeError) as exc:
        message = payload.get("error", {}).get("message", "No text returned") if isinstance(payload, dict) else "No text returned"
        raise RuntimeError(f"Gemini returned an unexpected response: {message}") from exc
    return validate_design(_extract_json(response_text))


# ---- V30: firmware generation and lightweight static design checks ----
def validate_connections(design):
    """Return heuristic warnings; this is not an electrical-rule checker or certification."""
    warnings = []
    components = design.get("components", [])
    connections = design.get("connections", [])
    component_text = " ".join(str(c.get(k, "")) for c in components for k in ("name", "value_or_model", "purpose")).lower()
    connection_text = " ".join(str(x.get(k, "")) for x in connections for k in ("from", "to", "details")).lower()
    combined = component_text + " " + connection_text
    if any(k in component_text for k in ("esp32", "esp-32", "esp8266", "arduino", "microcontroller")):
        if not any(k in connection_text for k in ("gnd", "ground")):
            warnings.append("No explicit common-ground connection was found. Confirm all low-voltage modules share ground where required.")
        if "5v" in combined and any(k in component_text for k in ("esp32", "esp-32")):
            warnings.append("A 5 V signal or supply is mentioned with an ESP32. Verify the exact pin and module; ESP32 GPIOs are not 5 V tolerant.")
        if any(k in component_text for k in ("pir", "hc-sr501")) and not any(k in connection_text for k in ("pir", "motion")):
            warnings.append("A PIR sensor is listed but its signal connection is not clearly described.")
    if "led" in component_text and not any(k in combined for k in ("resistor", "current limit", "current-limiting")):
        warnings.append("An LED is listed, but a series current-limiting resistor is not clearly specified.")
    if any(k in component_text for k in ("dht22", "am2302")) and not any(k in combined for k in ("pull-up", "pull up")):
        warnings.append("DHT22/AM2302 data line may require a pull-up resistor; verify whether your module already includes one.")
    if not warnings:
        warnings.append("No obvious issue was detected by the basic text checks. This does not prove the design is electrically correct.")
    return warnings


def generate_firmware(prompt: str, design: dict) -> str:
    """Ask Gemini for Arduino-ESP32 firmware, keeping the API key server-side."""
    api_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured on the backend.")
    if not prompt or len(prompt.strip()) < 8:
        raise ValueError("Please provide a project description before generating firmware.")
    model = os.environ.get("GEMINI_MODEL", DEFAULT_MODEL).strip()
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
    instruction = """You are CircuitMind's embedded firmware assistant. Generate Arduino IDE C++ firmware for ESP32 only when appropriate. Return plain source code only, no markdown fences. Use the supplied design and original request. Use the exact GPIO pins stated in the design where plausible; if a required pin or sensor detail is ambiguous, add a clearly marked TODO comment rather than inventing certainty. Include setup(), loop(), serial diagnostics, sensible timing with millis() where practical, input/output modes, and error handling. For DHT sensors, use the DHT sensor library and state required library names in comments. Never put API keys or secrets in code. Do not claim compilation or hardware testing occurred. Do not generate mains-voltage control instructions. If the request is not suitable for ESP32 firmware, return a short C++ comment explaining why."""
    user_content = "PROJECT REQUEST:\n" + prompt.strip() + "\n\nSTRUCTURED DESIGN JSON:\n" + json.dumps(design, ensure_ascii=False)
    body = {"systemInstruction": {"parts": [{"text": instruction}]}, "contents": [{"role": "user", "parts": [{"text": user_content}]}], "generationConfig": {"temperature": 0.2}}
    request = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:1000]
        if exc.code == 429:
            raise RuntimeError("Gemini quota/rate limit reached. Check AI Studio quotas and retry later.") from exc
        raise RuntimeError(f"Gemini firmware request failed (HTTP {exc.code}): {detail}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not reach Gemini: {exc.reason}") from exc
    try:
        code = payload["candidates"][0]["content"]["parts"][0]["text"].strip()
    except (KeyError, IndexError, TypeError) as exc:
        raise RuntimeError("Gemini returned no firmware text. Try again with a more specific prompt.") from exc
    if code.startswith("```"):
        code = re.sub(r"^```(?:cpp|c\+\+|arduino|ino)?\s*", "", code, flags=re.I)
        code = re.sub(r"\s*```$", "", code)
    if len(code) > 50000:
        raise RuntimeError("Generated firmware exceeded the safety size limit.")
    return code
