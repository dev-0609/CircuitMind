CircuitMind V34 — Shared Circuit Model Foundation

This prototype builds on the V33 app and adds a lightweight shared circuit data model.
It is a foundation for the planned React drag-and-drop schematic editor; this release
DOES NOT yet include the visual drag-and-drop canvas.

Files
- main.py: Streamlit prototype app, existing circuit labs, AI designer and RC workflow.
- circuitmind_model.py: shared JSON model, RC example, structural validator and clone helper.
- circuitmind_parsing.py: RC natural-language parsing helpers.
- circuitmind_verification.py: RC simulation-versus-theory checks.
- circuitmind_ai.py: Gemini integration.
- api.py: FastAPI endpoints.
- tests/: parser, verification and shared-model unit tests.

Run on Windows PowerShell
1. Open this folder in VS Code.
2. python -m pip install -r requirements.txt
3. Set the Gemini key if using AI features: $env:GEMINI_API_KEY="YOUR_KEY"
4. python -m unittest discover -s tests -v
5. python -m streamlit run main.py

Optional API server
python -m uvicorn api:app --reload --host 127.0.0.1 --port 8000

V34 scope
- Adds a common structured model for component IDs/types/values and named electrical nets.
- Adds basic structural checks: component IDs, supported terminal names, positive values,
  and net terminal references.
- Shows an example RC model and its structural validation in the Streamlit app.
- Keeps existing V33 functionality as the starting point.

Limitations
- The shared model is not yet the source of truth for existing simulation functions.
- The validator is not a full electrical rule checker and does not certify safety.
- The React drag-and-drop canvas and generic model-to-SPICE compiler are future milestones.
- Gemini output and generated firmware are not guaranteed to be electrically correct,
  compiled, or hardware-tested.
