import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from circuitmind_model import clone_circuit_model, rc_example, validate_circuit_model


class CircuitModelTests(unittest.TestCase):
    def test_rc_example_is_structurally_valid(self):
        result = validate_circuit_model(rc_example())
        self.assertTrue(result["valid"], result["errors"])

    def test_duplicate_component_ids_are_rejected(self):
        model = rc_example()
        model["components"].append(dict(model["components"][1]))
        result = validate_circuit_model(model)
        self.assertFalse(result["valid"])
        self.assertTrue(any("Duplicate component id" in error for error in result["errors"]))

    def test_unknown_component_reference_is_rejected(self):
        model = rc_example()
        model["nets"]["input"].append("R404.1")
        result = validate_circuit_model(model)
        self.assertFalse(result["valid"])
        self.assertTrue(any("unknown component" in error for error in result["errors"]))

    def test_invalid_terminal_is_rejected(self):
        model = rc_example()
        model["nets"]["input"] = ["V1.+", "R1.3"]
        result = validate_circuit_model(model)
        self.assertFalse(result["valid"])
        self.assertTrue(any("invalid for component type" in error for error in result["errors"]))

    def test_nonpositive_component_value_is_rejected(self):
        model = rc_example()
        model["components"][1]["value"] = 0
        result = validate_circuit_model(model)
        self.assertFalse(result["valid"])

    def test_clone_is_independent(self):
        original = rc_example()
        copied = clone_circuit_model(original)
        copied["components"][1]["value"] = 2200
        self.assertEqual(original["components"][1]["value"], 1000)


if __name__ == "__main__":
    unittest.main(verbosity=2)
