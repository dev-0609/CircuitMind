import math
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from circuitmind_verification import theoretical_rc_voltage, verify_rc_step_response


class RCVerificationTests(unittest.TestCase):
    def test_theory_at_one_time_constant(self):
        self.assertAlmostEqual(theoretical_rc_voltage(0.1, 5, 1000, 100e-6), 3.1606, places=3)

    def test_ideal_curve_passes(self):
        r, c, vin = 1000.0, 100e-6, 5.0
        times = [i * 0.0004 for i in range(501)]
        volts = [theoretical_rc_voltage(t, vin, r, c) for t in times]
        result = verify_rc_step_response(times, volts, vin, r, c)
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(result["monotonic_rise"])
        self.assertLess(result["max_absolute_error_v"], 1e-9)

    def test_wrong_falling_curve_fails(self):
        times = [i * 0.0004 for i in range(501)]
        charging = [theoretical_rc_voltage(t, 5, 1000, 100e-6) for t in times]
        volts = [v if t <= 0.1 else theoretical_rc_voltage(0.1, 5, 1000, 100e-6) * math.exp(-(t - 0.1) / 0.1) for t, v in zip(times, charging)]
        result = verify_rc_step_response(times, volts, 5, 1000, 100e-6)
        self.assertEqual(result["status"], "FAIL")
        self.assertFalse(result["monotonic_rise"])

    def test_mismatched_arrays_rejected(self):
        with self.assertRaises(ValueError):
            verify_rc_step_response([0, 1], [0], 5, 1000, 100e-6)

    def test_nonincreasing_time_rejected(self):
        with self.assertRaises(ValueError):
            verify_rc_step_response([0, 0], [0, 1], 5, 1000, 100e-6)


if __name__ == "__main__":
    unittest.main(verbosity=2)
