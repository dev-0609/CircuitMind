import math
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from circuitmind_parsing import parse_rc_request


class RCParserTests(unittest.TestCase):
    def assert_design(self, prompt, r, c_uf, vin):
        result = parse_rc_request(prompt)
        self.assertTrue(math.isclose(result["r_ohm"], r, rel_tol=1e-9))
        self.assertTrue(math.isclose(result["c_uf"], c_uf, rel_tol=1e-9))
        self.assertTrue(math.isclose(result["vin"], vin, rel_tol=1e-9))

    def test_labeled_kohm_and_microfarad(self):
        self.assert_design("R = 1 kOhm and C = 100 uF with 5 V step input", 1000, 100, 5)

    def test_attached_units(self):
        self.assert_design("RC low pass, R=2.2k, C=47uF, input 3.3V", 2200, 47, 3.3)

    def test_nanofarad(self):
        self.assert_design("R 1000 ohm C 100 nF, 12 volts step input", 1000, 0.1, 12)

    def test_plain_component_descriptions(self):
        self.assert_design("1 kOhm resistor, 0.1 uF capacitor, 5V step input", 1000, 0.1, 5)


    def test_common_resistance_and_capacitance_spellings(self):
        cases = [
            ("R=1 kΩ, C=100 µF, 5 V step input", 1000, 100, 5),
            ("R=1000 ohms, C=0.0001 F, input 5 volts", 1000, 100, 5),
            ("R=1k, C=100uF, input 5V", 1000, 100, 5),
            ("1 kilo ohm resistor, 100 microfarads capacitor, 5 V input", 1000, 100, 5),
            ("R=2.2 kOhm, C=47 nF, 3.3 V step", 2200, 0.047, 3.3),
            ("R=1 megohm, C=10 pF, 5 V input", 1e6, 0.00001, 5),
        ]
        for prompt, r, c_uf, vin in cases:
            with self.subTest(prompt=prompt):
                self.assert_design(prompt, r, c_uf, vin)

    def test_scientific_notation(self):
        self.assert_design("R=1e3 ohm, C=1e-4 F, 5V input", 1000, 100, 5)

    def test_fallback_component_text_when_prompt_omits_explicit_resistance(self):
        result = parse_rc_request(
            "Build an RC low-pass filter with a 5 V step input",
            fallback_text="Resistor value_or_model: 1 kOhm; Capacitor value_or_model: 100 uF",
        )
        self.assertTrue(math.isclose(result["r_ohm"], 1000, rel_tol=1e-9))
        self.assertTrue(math.isclose(result["c_uf"], 100, rel_tol=1e-9))
        self.assertTrue(math.isclose(result["vin"], 5, rel_tol=1e-9))

    def test_empty_prompt_rejected(self):
        with self.assertRaises(ValueError):
            parse_rc_request("")

    def test_missing_voltage_rejected(self):
        with self.assertRaises(ValueError):
            parse_rc_request("R=1kOhm C=100uF")

    def test_missing_capacitance_rejected(self):
        with self.assertRaises(ValueError):
            parse_rc_request("R=1kOhm, 5V step input")

    def test_nonpositive_values_rejected(self):
        with self.assertRaises(ValueError):
            parse_rc_request("R=0 ohm C=100uF, 5V input")


if __name__ == "__main__":
    unittest.main(verbosity=2)
