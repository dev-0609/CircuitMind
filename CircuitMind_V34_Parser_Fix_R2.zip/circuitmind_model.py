"""CircuitMind shared circuit representation (V34 prototype foundation).

This is a lightweight data model for supported circuit prototypes, not a full
schematic parser or electrical rule engine. Connections are represented as nets
containing component terminal references, suitable for a future React canvas.
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any

SUPPORTED_COMPONENT_TYPES = {
    "resistor": {"1", "2"},
    "capacitor": {"1", "2"},
    "inductor": {"1", "2"},
    "voltage_source": {"+", "-"},
    "diode": {"anode", "cathode"},
    "led": {"anode", "cathode"},
    "ground": {"0"},
}


def rc_example() -> dict[str, Any]:
    """Return a canonical 5 V, 1 kOhm, 100 uF RC low-pass example."""
    return {
        "schema_version": "1.0",
        "circuit_id": "rc_low_pass_demo",
        "name": "RC low-pass filter",
        "topology": "rc_low_pass",
        "components": [
            {"id": "V1", "type": "voltage_source", "value": 5.0, "unit": "V"},
            {"id": "R1", "type": "resistor", "value": 1000.0, "unit": "ohm"},
            {"id": "C1", "type": "capacitor", "value": 0.0001, "unit": "F"},
            {"id": "GND", "type": "ground", "value": None, "unit": None},
        ],
        "nets": {
            "input": ["V1.+", "R1.1"],
            "output": ["R1.2", "C1.1"],
            "ground": ["V1.-", "C1.2", "GND.0"],
        },
        "simulation": {"engine": "ngspice", "analysis": "transient", "stop_time_s": 0.2},
    }


def validate_circuit_model(model: dict[str, Any]) -> dict[str, Any]:
    """Perform basic structural checks and return {valid, errors, warnings}.

    These checks verify the model's structure and terminal references only. They
    do not establish electrical correctness, safety, or simulation support.
    """
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(model, dict):
        return {"valid": False, "errors": ["Circuit model must be a JSON object."], "warnings": warnings}
    components = model.get("components")
    nets = model.get("nets")
    if not isinstance(components, list) or not components:
        errors.append("components must be a non-empty list.")
        components = []
    if not isinstance(nets, dict) or not nets:
        errors.append("nets must be a non-empty object mapping net names to terminals.")
        nets = {}

    by_id: dict[str, dict[str, Any]] = {}
    for index, component in enumerate(components):
        if not isinstance(component, dict):
            errors.append(f"Component at index {index} must be an object.")
            continue
        component_id = component.get("id")
        component_type = component.get("type")
        if not isinstance(component_id, str) or not component_id.strip():
            errors.append(f"Component at index {index} has a missing/invalid id.")
            continue
        if component_id in by_id:
            errors.append(f"Duplicate component id: {component_id}.")
            continue
        by_id[component_id] = component
        if component_type not in SUPPORTED_COMPONENT_TYPES:
            errors.append(f"Component {component_id} has unsupported type {component_type!r}.")
            continue
        value = component.get("value")
        if component_type != "ground":
            if not isinstance(value, (int, float)) or isinstance(value, bool) or value <= 0:
                errors.append(f"Component {component_id} must have a positive numeric value.")

    terminal_uses: dict[str, int] = {}
    for net_name, terminals in nets.items():
        if not isinstance(net_name, str) or not net_name.strip():
            errors.append("Net names must be non-empty strings.")
            continue
        if not isinstance(terminals, list) or len(terminals) < 2:
            errors.append(f"Net {net_name!r} must connect at least two terminals.")
            continue
        for terminal_ref in terminals:
            if not isinstance(terminal_ref, str) or "." not in terminal_ref:
                errors.append(f"Invalid terminal reference {terminal_ref!r} in net {net_name!r}.")
                continue
            component_id, terminal = terminal_ref.rsplit(".", 1)
            component = by_id.get(component_id)
            if component is None:
                errors.append(f"Net {net_name!r} references unknown component {component_id!r}.")
                continue
            allowed = SUPPORTED_COMPONENT_TYPES.get(component.get("type"), set())
            if terminal not in allowed:
                errors.append(f"Terminal {terminal_ref!r} is invalid for component type {component.get('type')!r}.")
                continue
            terminal_uses[terminal_ref] = terminal_uses.get(terminal_ref, 0) + 1
    for component_id, component in by_id.items():
        allowed = SUPPORTED_COMPONENT_TYPES.get(component.get("type"), set())
        for terminal in allowed:
            ref = f"{component_id}.{terminal}"
            if terminal_uses.get(ref, 0) == 0:
                warnings.append(f"Terminal {ref} is not connected to any net.")
            elif terminal_uses[ref] > 1:
                errors.append(f"Terminal {ref} appears in more than one net.")
    warnings.append("Structural validation only; electrical correctness and simulation compatibility are not certified.")
    return {"valid": not errors, "errors": errors, "warnings": warnings}


def clone_circuit_model(model: dict[str, Any]) -> dict[str, Any]:
    """Return a deep copy suitable for editing without mutating the original."""
    return deepcopy(model)
