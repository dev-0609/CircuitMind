"""Headless ngspice simulation functions shared with the Streamlit app."""
import os, re, shutil, subprocess, tempfile
from pathlib import Path
DEFAULT_NGSPICE = r"E:\ngspice\ngspice-47_64\Spice64\bin\ngspice_con.exe"
NGSPICE_EXE = os.environ.get("NGSPICE_EXE", DEFAULT_NGSPICE)

def find_ngspice():
    """Find ngspice at the configured path or on PATH."""
    configured = Path(NGSPICE_EXE)
    if configured.is_file():
        return str(configured)
    for command in ("ngspice_con.exe", "ngspice.exe", "ngspice"):
        found = shutil.which(command)
        if found:
            return found
    return None

def simulate_transient_component_circuit(kind, vin, resistance, capacitance_uf, inductance_mh=10.0):
    """Run ngspice transient analysis for RC or series-RLC circuits.

    The source is a repeating pulse so the capacitor/inductor response is visible.
    Returns sampled time/output-voltage arrays, log, and the generated netlist.
    """
    executable = find_ngspice()
    if not executable:
        raise FileNotFoundError("Could not find ngspice. Configure DEFAULT_NGSPICE or NGSPICE_EXE.")
    if vin <= 0 or resistance <= 0 or capacitance_uf <= 0:
        raise ValueError("Supply voltage, resistance, and capacitance must be positive.")
    if kind == "RLC" and inductance_mh <= 0:
        raise ValueError("Inductance must be positive.")

    # Select a useful display window based on the circuit time constants.
    capacitance_f = capacitance_uf * 1e-6
    inductance_h = inductance_mh * 1e-3
    tau = resistance * capacitance_f
    if kind == "RC":
        stop_time = max(0.01, min(0.2, 8 * tau))
    else:
        # A few natural periods, with a practical upper bound for a demo.
        import math
        natural_period = 2 * math.pi * math.sqrt(inductance_h * capacitance_f)
        stop_time = max(0.005, min(0.1, 8 * natural_period, 8 * max(tau, 1e-5)))
    step = stop_time / 500
    # Keep the source HIGH for the entire simulated window. The previous
    # stop_time / 2 pulse width caused the input to fall halfway through the
    # run, so the RC capacitor charged and then discharged unexpectedly.
    pulse_width = stop_time * 2
    pulse_period = stop_time * 4
    if kind == "RC":
        elements = f"R1 in out {resistance:.12g}\nC1 out 0 {capacitance_f:.12g}"
        title = "CircuitMind RC transient circuit"
    else:
        elements = (
            f"R1 in n1 {resistance:.12g}\n"
            f"L1 n1 out {inductance_h:.12g}\n"
            f"C1 out 0 {capacitance_f:.12g}"
        )
        title = "CircuitMind series RLC transient circuit"

    netlist = f"""{title}
V1 in 0 PULSE(0 {float(vin):.12g} 0 {step:.12g} {step:.12g} {pulse_width:.12g} {pulse_period:.12g})
{elements}
.control
set wr_singlescale
set wr_vecnames
tran {step:.12g} {stop_time:.12g}
wrdata transient.dat v(out)
quit
.endc
.end
"""
    with tempfile.TemporaryDirectory() as temp_dir:
        circuit_file = Path(temp_dir) / "transient.cir"
        data_file = Path(temp_dir) / "transient.dat"
        circuit_file.write_text(netlist, encoding="ascii")
        result = subprocess.run(
            [executable, "-b", str(circuit_file)], capture_output=True, text=True,
            timeout=25, cwd=temp_dir, errors="replace"
        )
        output = (result.stdout or "") + "\n" + (result.stderr or "")
        if result.returncode != 0:
            raise RuntimeError("ngspice returned an error:\n" + output[-2500:])
        if not data_file.exists():
            raise RuntimeError("ngspice completed but did not create transient data. Output:\n" + output[-2500:])
        times, voltages = [], []
        for line in data_file.read_text(encoding="utf-8", errors="replace").splitlines():
            parts = line.strip().split()
            if len(parts) < 2:
                continue
            try:
                t = float(parts[0])
                v = float(parts[-1])
            except ValueError:
                continue  # Skip the optional vector-name header.
            times.append(t)
            voltages.append(v)
    if len(times) < 2:
        raise RuntimeError("Could not parse transient samples from ngspice output:\n" + output[-2500:])
    return times, voltages, output, netlist, stop_time
