"""Frontend-independent CircuitMind API. Run with: uvicorn api:app --reload"""
import os
from typing import Any
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from circuitmind_ai import generate_design, generate_firmware, validate_connections
from circuitmind_parsing import parse_rc_request
from circuitmind_verification import verify_rc_step_response
from circuitmind_simulation import simulate_transient_component_circuit

app = FastAPI(title="CircuitMind API", version="0.1.0", description="AI circuit proposal API; generated designs are not automatically electrically verified.")
_origins = [x.strip() for x in os.environ.get("CIRCUITMIND_CORS_ORIGINS", "http://localhost:3000,http://localhost:5173").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=_origins, allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["Content-Type", "Authorization"])

class DesignRequest(BaseModel):
    prompt: str = Field(min_length=8, max_length=8000)

@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "circuitmind-api"}

@app.post("/api/v1/design")
def create_design(request: DesignRequest) -> dict[str, Any]:
    try:
        design = generate_design(request.prompt)
        design["connection_check_warnings"] = validate_connections(design)
        return design
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail="Unexpected AI service error. Check backend logs.") from exc


class FirmwareRequest(BaseModel):
    prompt: str = Field(min_length=8, max_length=8000)
    design: dict[str, Any]

@app.post("/api/v1/firmware")
def create_firmware(request: FirmwareRequest) -> dict[str, str]:
    try:
        return {"firmware": generate_firmware(request.prompt, request.design), "status": "generated_not_compiled_or_hardware_tested"}
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail="Unexpected AI service error. Check backend logs.") from exc


class SimulationRequest(BaseModel):
    prompt: str = Field(min_length=8, max_length=8000)
    design: dict[str, Any] | None = None

@app.post("/api/v1/simulate/rc")
def simulate_rc(request: SimulationRequest) -> dict[str, Any]:
    """Run the backend's supported RC step-response workflow in ngspice."""
    try:
        design_text = ""
        if request.design and isinstance(request.design.get("components"), list):
            design_text = " ".join(
                str(component.get(field, ""))
                for component in request.design["components"] if isinstance(component, dict)
                for field in ("name", "value_or_model", "purpose")
            )
        values = parse_rc_request(request.prompt, fallback_text=design_text)
        times, voltages, log, netlist, stop_time = simulate_transient_component_circuit(
            "RC", values["vin"], values["r_ohm"], values["c_uf"]
        )
        tau = values["r_ohm"] * values["c_f"]
        verification = verify_rc_step_response(times, voltages, values["vin"], values["r_ohm"], values["c_f"])
        return {
            "status": "simulated",
            "engine": "ngspice",
            "values": values,
            "time_s": times,
            "voltage_v": voltages,
            "stop_time_s": stop_time,
            "time_constant_s": tau,
            "cutoff_hz": 1 / (2 * 3.141592653589793 * tau),
            "verification": verification,
            "netlist": netlist,
            "log": log[-6000:],
        }
    except (ValueError, RuntimeError, FileNotFoundError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail="Simulation failed unexpectedly. Check backend logs and ngspice configuration.") from exc
