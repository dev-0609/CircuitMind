# CircuitMind integration bundle

- `backend/` is the user's existing Python/Streamlit engine plus a FastAPI wrapper and headless ngspice RC simulation adapter.
- `frontend/brightboard-circuit-doctor-main/` preserves the supplied animated 3D React frontend and adds real API calls to its Design and Simulate sections.

Read `frontend/brightboard-circuit-doctor-main/README-CIRCUITMIND-INTEGRATION.md` for setup instructions.

Important: keep `GEMINI_API_KEY` only in the backend terminal environment. The backend still includes the original Streamlit `main.py`; it has not been replaced. The frontend visuals for diagnosis/fault/repair are not yet backed by real diagnosis/repair endpoints.
