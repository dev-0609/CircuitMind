# CircuitMind frontend ↔ Python backend

The animated React UI is retained. Live controls now call the Python API for Gemini design proposals and the supported ngspice RC workflow.

## Start the backend (Windows PowerShell)

From the `backend` folder:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
# Set this if ngspice is not on PATH:
$env:NGSPICE_EXE="E:\ngspice\ngspice-47_64\Spice64\bin\ngspice_con.exe"
$env:CIRCUITMIND_CORS_ORIGINS="http://localhost:5173,http://127.0.0.1:5173"
uvicorn api:app --host 127.0.0.1 --port 8000
```

Keep this terminal open. The API key stays in the backend environment; never put it in a `VITE_*` variable.

## Start the frontend

In a second terminal, from `frontend/brightboard-circuit-doctor-main`:

```powershell
npm install
npm run dev
```

Open the local URL Vite prints. Optional: copy `.env.example` to `.env.local` if the backend is not at `http://127.0.0.1:8000`, then set `VITE_CIRCUITMIND_API_URL` to the API base URL.

## Live features currently wired

- Design section → `POST /api/v1/design` (Gemini structured proposal and basic text-based warnings).
- Simulate section → `POST /api/v1/simulate/rc` (parses explicit R/C/step voltage, runs ngspice, returns samples, theory comparison, netlist and logs).
- Firmware endpoint remains available at `POST /api/v1/firmware` for future UI wiring.

The RC endpoint supports the existing RC topology only; it does not simulate arbitrary Gemini connection tables. The design, diagnose, fault and repair scene illustrations remain visual storytelling/demo elements unless explicitly driven by a live result. Firmware generation is not compile- or hardware-tested. A successful frontend build or API response does not certify electrical safety.
