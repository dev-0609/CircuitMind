import { motion, useTransform, type MotionValue } from "framer-motion";
import { useState } from "react";
import { circuitMindApi, type RcSimulation } from "@/lib/circuitmind-api";
import { PinnedSection, SectionHeading } from "./PinnedSection";

const W = 400;
const H = 200;

const charge = Array.from({ length: 201 }, (_, i) => {
  const x = (i / 200) * W;
  const v = 5 * (1 - Math.exp(-i / 28)) + (i > 90 ? Math.sin(i * 0.9) * 0.06 : 0);
  return `${i ? "L" : "M"}${x.toFixed(1)} ${(H - 20 - (v / 5) * 140).toFixed(1)}`;
}).join(" ");

const current = Array.from({ length: 201 }, (_, i) => {
  const x = (i / 200) * W;
  const a = 20 * Math.exp(-i / 28);
  return `${i ? "L" : "M"}${x.toFixed(1)} ${(H - 20 - (a / 20) * 140 * 0.9).toFixed(1)}`;
}).join(" ");

export function SimulateSection() {
  return <PinnedSection id="simulate" index={2}>{(p) => <SimInner p={p} />}</PinnedSection>;
}

function SimInner({ p }: { p: MotionValue<number> }) {
  const draw = useTransform(p, [0.15, 0.75], [0, 1]);
  const beam = useTransform(p, [0.15, 0.75], ["0%", "100%"]);
  const vout = useTransform(p, [0.15, 0.75], [0, 4.98]);
  const amps = useTransform(p, [0.15, 0.75], [0, 19.6]);
  const voutText = useTransform(vout, (v) => v.toFixed(2));
  const ampsText = useTransform(amps, (v) => v.toFixed(1));
  const panelX = useTransform(p, [0, 0.18], [100, 0]);
  const panelO = useTransform(p, [0, 0.12], [0, 1]);
  const [prompt, setPrompt] = useState("R = 1 kOhm, C = 100 uF, 5 V step input");
  const [result, setResult] = useState<RcSimulation | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const runSimulation = async () => { setBusy(true); setError(""); try { setResult(await circuitMindApi.simulateRc(prompt)); } catch (e) { setError(e instanceof Error ? e.message : "Simulation request failed"); } finally { setBusy(false); } };

  return (
    <div className="mx-auto grid w-full max-w-6xl items-center gap-10 md:grid-cols-[0.9fr_1.1fr]">
      <SectionHeading
        step="02"
        kicker="Simulate"
        tone="text-phosphor"
        title="Proven in ngspice."
        line="Every design is run through a real circuit simulator before you trust it."
      />
      <motion.div style={{ x: panelX, opacity: panelO }} className="glass-panel overflow-hidden p-5 md:p-6">
        <div className="mb-3 flex items-center justify-between font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
          <span>.tran 1ms</span>
          <span className="flex items-center gap-2 text-phosphor">
            <span className="size-1.5 rounded-full bg-current glow-dot animate-pulse-glow" /> live
          </span>
        </div>
        <div className="relative aspect-[2/1] rounded-lg border border-phosphor/20 scope-grid">
          <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="absolute inset-0 h-full w-full" fill="none">
            <line x1="0" x2={W} y1="40" y2="40" className="stroke-phosphor/40" strokeDasharray="4 6" />
            <motion.path d={current} className="stroke-role-capacitor" strokeWidth="1.5" style={{ pathLength: draw }} opacity={0.7} />
            <motion.path d={charge} className="stroke-phosphor" strokeWidth="2.5" style={{ pathLength: draw }} />
          </svg>
          <motion.div style={{ left: beam }} className="absolute inset-y-0 w-px bg-phosphor text-phosphor glow-dot" />
        </div>
        <div className="mt-5 border-t border-border/70 pt-4">
          <label htmlFor="circuitmind-rc-prompt" className="mb-2 block font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Run real RC transient simulation</label>
          <textarea id="circuitmind-rc-prompt" value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={2} className="w-full resize-y rounded-lg border border-phosphor/30 bg-background/70 p-3 text-sm text-foreground outline-none focus:border-phosphor" />
          <button type="button" disabled={busy || prompt.trim().length < 8} onClick={runSimulation} className="mt-3 rounded-md border border-phosphor/50 bg-phosphor/10 px-4 py-2 font-mono text-xs uppercase tracking-wider text-foreground transition hover:bg-phosphor/20 disabled:opacity-50">{busy ? "Running ngspice…" : "Run ngspice ↗"}</button>
          {error && <p role="alert" className="mt-3 text-sm text-fault">{error}</p>}
          {result && <div className="mt-4 rounded-lg border border-phosphor/30 bg-background/60 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2"><span className="font-mono text-xs uppercase tracking-wider text-phosphor">{result.engine} · {result.status}</span><span className={`font-mono text-xs ${result.verification.passed ? "text-ok" : "text-fault"}`}>Theory check: {result.verification.passed ? "PASS" : "CHECK"}</span></div>
            <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-3"><Metric label="Time constant τ" value={`${result.time_constant_s.toPrecision(4)} s`} /><Metric label="Cutoff" value={`${result.cutoff_hz.toPrecision(4)} Hz`} /><Metric label="Final V(out)" value={`${result.voltage_v.at(-1)?.toFixed(3) ?? "—"} V`} /></div>
            <div className="mt-4 rounded border border-border/70 p-2"><svg viewBox="0 0 500 190" className="h-44 w-full" role="img" aria-label="Voltage waveform returned by ngspice"><path d="M35 12 V160 H490" stroke="currentColor" strokeOpacity=".35" fill="none" />{result.voltage_v.length > 1 && <path d={result.voltage_v.map((v, i) => `${i ? "L" : "M"}${35 + (i / (result.voltage_v.length - 1)) * 450},${155 - (v / Math.max(result.values.vin, 0.01)) * 135}`).join(" ")} stroke="hsl(var(--phosphor))" strokeWidth="2.5" fill="none" />}</svg><div className="flex justify-between px-2 font-mono text-[10px] text-muted-foreground"><span>0 s</span><span>{result.stop_time_s.toPrecision(3)} s</span></div></div>
            <p className="mt-3 text-xs text-muted-foreground">Maximum theory error: {result.verification.max_absolute_error_v.toFixed(4)} V · tolerance {result.verification.tolerance_v.toFixed(3)} V. The waveform above uses simulator-returned samples.</p>
            <details className="mt-3"><summary className="cursor-pointer font-mono text-xs text-blueprint">View generated SPICE netlist</summary><pre className="mt-2 max-h-48 overflow-auto whitespace-pre-wrap rounded bg-background p-3 text-xs text-muted-foreground">{result.netlist}</pre></details>
          </div>}
        </div>

        <div className="mt-4 grid grid-cols-3 gap-3 font-mono">
          <Readout label="V out" unit="V" value={voutText} tone="text-phosphor" />
          <Readout label="I led" unit="mA" value={ampsText} tone="text-role-capacitor" />
          <div className="rounded-lg border border-border bg-background/40 px-3 py-2">
            <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Engine</div>
            <div className="text-sm text-foreground">ngspice</div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function Readout({ label, unit, value, tone }: { label: string; unit: string; value: MotionValue<string>; tone: string }) {
  return (
    <div className="rounded-lg border border-border bg-background/40 px-3 py-2">
      <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{label}</div>
      <div className={`text-lg tabular-nums ${tone}`}>
        <motion.span>{value}</motion.span>
        <span className="ml-1 text-xs text-muted-foreground">{unit}</span>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div className="rounded border border-border/70 px-3 py-2"><div className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div><div className="mt-1 font-mono text-sm text-foreground">{value}</div></div>;
}
