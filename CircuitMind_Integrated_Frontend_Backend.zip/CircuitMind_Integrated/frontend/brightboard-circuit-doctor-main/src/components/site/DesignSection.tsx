import { motion, useMotionValueEvent, useTransform, type MotionValue } from "framer-motion";
import { useState } from "react";
import { circuitMindApi, type CircuitDesign } from "@/lib/circuitmind-api";
import { cn } from "@/lib/utils";
import { PinnedSection, SectionHeading, range } from "./PinnedSection";

const PROMPT = "5 V supply, LED indicator, limit to 20 mA";
const LOOP = "M70 120 V60 H150 M240 60 H340 V110 M340 135 V220 H70 V134";
const RESISTOR = "M150 60 l8 -12 l15 24 l15 -24 l15 24 l15 -24 l15 24 l7 -12";

export function DesignSection() {
  return <PinnedSection id="design" index={1}>{(p) => <DesignInner p={p} />}</PinnedSection>;
}

function DesignInner({ p }: { p: MotionValue<number> }) {
  const [chars, setChars] = useState(0);
  const [done, setDone] = useState(false);
  const [prompt, setPrompt] = useState("Design a 5 V RC low-pass circuit with R = 1 kOhm and C = 100 uF, and a 5 V step input");
  const [design, setDesign] = useState<CircuitDesign | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [showDetails, setShowDetails] = useState(false);
  const generate = async () => { setBusy(true); setError(""); try { setDesign(await circuitMindApi.design(prompt)); setShowDetails(true); } catch (e) { setError(e instanceof Error ? e.message : "Design request failed"); } finally { setBusy(false); } };
  useMotionValueEvent(p, "change", (v) => {
    setChars(Math.round(range(v, 0.06, 0.3) * PROMPT.length));
    setDone(v > 0.82);
  });
  const wires = useTransform(p, [0.3, 0.62], [0, 1]);
  const parts = useTransform(p, [0.45, 0.75], [0, 1]);
  const labels = useTransform(p, [0.72, 0.82], [0, 1]);
  const panelY = useTransform(p, [0, 0.18], [80, 0]);
  const panelO = useTransform(p, [0, 0.12], [0, 1]);

  return (
    <div className="mx-auto grid w-full max-w-6xl items-center gap-10 md:grid-cols-[0.9fr_1.1fr]">
      <SectionHeading
        step="01"
        kicker="Design"
        tone="text-blueprint"
        title="Say it. It's wired."
        line="Plain-language requirements become a real, buildable schematic."
      />
      <motion.div style={{ y: panelY, opacity: panelO }} className="glass-panel p-5 md:p-6">
        <div className="flex items-center gap-3 rounded-lg border border-blueprint/30 bg-background/50 px-4 py-3 font-mono text-sm">
          <span className="text-blueprint">›</span>
          <span className="text-foreground">{PROMPT.slice(0, chars)}</span>
          <span className="-ml-2 h-4 w-2 bg-blueprint animate-blink" />
        </div>

        <svg viewBox="0 0 420 270" className="mt-5 w-full" fill="none" strokeLinecap="round" strokeLinejoin="round">
          <motion.path d={LOOP} className="stroke-copper" strokeWidth="2.5" style={{ pathLength: wires }} />
          {/* battery */}
          <motion.path d="M48 120 H92 M58 134 H82" className="stroke-electric" strokeWidth="3" style={{ pathLength: parts }} />
          {/* resistor */}
          <motion.path d={RESISTOR} className="stroke-role-resistor" strokeWidth="3" style={{ pathLength: parts }} />
          {/* LED */}
          <motion.path
            d="M325 110 H355 L340 135 Z M325 135 H355 M362 116 l13 -10 M368 104 l7 2 l-2 7 M366 128 l13 -10 M372 116 l7 2 l-2 7"
            className="stroke-role-diode"
            strokeWidth="2.5"
            style={{ pathLength: parts }}
          />
          {/* ground */}
          <motion.path d="M205 220 V236 M190 236 H220 M195 243 H215 M200 250 H210" className="stroke-muted-foreground" strokeWidth="2" style={{ pathLength: parts }} />
          <motion.g style={{ opacity: labels }} className="fill-muted-foreground font-mono" fontSize="11">
            <text x="18" y="131">5V</text>
            <text x="160" y="34" className="fill-role-resistor">R1 · 150Ω</text>
            <text x="365" y="150" className="fill-role-diode">D1</text>
            <text x="225" y="252">GND</text>
          </motion.g>
          {done && (
            <circle r="4" className="fill-electric">
              <animateMotion dur="3.2s" repeatCount="indefinite" path="M70 120 V60 H340 V220 H70 Z" />
            </circle>
          )}
        </svg>

        <div className="mt-5 border-t border-border/70 pt-4">
          <label htmlFor="circuitmind-design-prompt" className="mb-2 block font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Live backend · Gemini circuit proposal</label>
          <textarea id="circuitmind-design-prompt" value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={3} className="w-full resize-y rounded-lg border border-blueprint/30 bg-background/70 p-3 text-sm text-foreground outline-none focus:border-blueprint" placeholder="Describe the circuit you want..." />
          <button type="button" disabled={busy || prompt.trim().length < 8} onClick={generate} className="mt-3 rounded-md border border-blueprint/50 bg-blueprint/10 px-4 py-2 font-mono text-xs uppercase tracking-wider text-foreground transition hover:bg-blueprint/20 disabled:opacity-50">{busy ? "Asking Gemini…" : "Generate real design ↗"}</button>
          {error && <p role="alert" className="mt-3 text-sm text-fault">{error}</p>}
          {design && <div className="mt-4 rounded-lg border border-ok/30 bg-background/60 p-4 text-sm">
            <div className="font-display text-base font-semibold text-ok">{design.project_title}</div><p className="mt-1 text-muted-foreground">{design.summary}</p>
            <div className="mt-3 flex flex-wrap gap-2">{design.components.map((c, i) => <span key={`${c.name}-${i}`} className="rounded border border-border px-2 py-1 font-mono text-xs">{c.name}: {c.value_or_model}</span>)}</div>
            <button type="button" onClick={() => setShowDetails(!showDetails)} className="mt-3 text-xs text-blueprint underline">{showDetails ? "Hide" : "Show"} connections & validation notes</button>
            {showDetails && <div className="mt-3 space-y-3"><div><b>Connections</b><ul className="mt-1 list-disc pl-5 text-muted-foreground">{design.connections.map((c, i) => <li key={i}>{c.from} → {c.to}: {c.details}</li>)}</ul></div><div><b>Validation notes</b><ul className="mt-1 list-disc pl-5 text-muted-foreground">{[...design.validation_notes, ...(design.connection_check_warnings || [])].map((n, i) => <li key={i}>{n}</li>)}</ul></div></div>}
          </div>}
        </div>

        <div className="mt-3 flex items-center justify-between font-mono text-xs uppercase tracking-[0.2em]">
          <span className="text-muted-foreground">netlist.cir</span>
          <span className={cn("transition-colors duration-500", done ? "text-ok" : "text-blueprint")}>
            {done ? "● ready to simulate" : "● generating…"}
          </span>
        </div>
      </motion.div>
    </div>
  );
}
