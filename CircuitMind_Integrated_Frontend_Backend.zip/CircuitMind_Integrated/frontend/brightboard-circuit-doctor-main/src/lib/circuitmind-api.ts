const API_BASE = (import.meta.env.VITE_CIRCUITMIND_API_URL || "http://127.0.0.1:8000").replace(/\/$/, "");

async function post<T>(path: string, body: unknown): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch {
    throw new Error(`Cannot reach CircuitMind backend at ${API_BASE}. Start the Python API and check CORS.`);
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = typeof payload.detail === "string" ? payload.detail : `Request failed (${response.status})`;
    throw new Error(detail);
  }
  return payload as T;
}

export type CircuitDesign = {
  project_title: string;
  summary: string;
  components: { name: string; quantity: number; value_or_model: string; purpose: string }[];
  connections: { from: string; to: string; details: string }[];
  assumptions: string[];
  validation_notes: string[];
  connection_check_warnings?: string[];
};

export type RcSimulation = {
  status: string;
  engine: string;
  values: { r_ohm: number; c_f: number; c_uf: number; vin: number };
  time_s: number[];
  voltage_v: number[];
  stop_time_s: number;
  time_constant_s: number;
  cutoff_hz: number;
  verification: { passed: boolean; max_absolute_error_v: number; tolerance_v: number; scope_note?: string };
  netlist: string;
  log: string;
};

export const circuitMindApi = {
  health: async () => {
    const response = await fetch(`${API_BASE}/health`);
    if (!response.ok) throw new Error("Backend health check failed");
    return response.json() as Promise<{ status: string; service: string }>;
  },
  design: (prompt: string) => post<CircuitDesign>("/api/v1/design", { prompt }),
  simulateRc: (prompt: string, design?: CircuitDesign) => post<RcSimulation>("/api/v1/simulate/rc", { prompt, design }),
  firmware: (prompt: string, design: CircuitDesign) => post<{ firmware: string; status: string }>("/api/v1/firmware", { prompt, design }),
};
