import { defaultParams } from "./catalog";
import type { CircuitDocument, CircuitElectrical, CircuitVisual, TemplateId } from "./types";

export const TEMPLATES: { id: TemplateId; name: string; description: string }[] = [
  { id: "led_series_resistor", name: "LED with series resistor", description: "5 V supply, 330 Ω resistor and an LED. Target: 10 mA ±10 %." },
  { id: "voltage_divider", name: "Voltage divider", description: "5 V across two 10 kΩ resistors. Target: 2.5 V across R2 ±5 %." },
  { id: "empty", name: "Empty circuit", description: "Start from a blank canvas." },
];

export function newId(prefix = "c") {
  const rnd = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10);
  return `${prefix}_${Date.now().toString(36)}${rnd}`;
}

function led(): { electrical: CircuitElectrical; visual: CircuitVisual } {
  return {
    electrical: {
      components: [
        { id: "V1", type: "dc_voltage_source", parameters: { voltage_v: 5 } },
        { id: "R1", type: "resistor", parameters: { resistance_ohms: 330 } },
        { id: "D1", type: "led", parameters: defaultParams("led") },
        { id: "GND1", type: "ground", parameters: {} },
      ],
      connections: [
        { id: "w1", from: { component_id: "V1", terminal: "positive" }, to: { component_id: "R1", terminal: "a" } },
        { id: "w2", from: { component_id: "R1", terminal: "b" }, to: { component_id: "D1", terminal: "anode" } },
        { id: "w3", from: { component_id: "D1", terminal: "cathode" }, to: { component_id: "GND1", terminal: "gnd" } },
        { id: "w4", from: { component_id: "V1", terminal: "negative" }, to: { component_id: "GND1", terminal: "gnd" } },
      ],
      targets: [{ id: "t1", metric: "current", component_id: "D1", target: 0.01, tolerance_pct: 10 }],
    },
    visual: {
      components: {
        V1: { position: { x: 60, y: 160 }, rotation: 90 },
        R1: { position: { x: 220, y: 40 }, rotation: 0 },
        D1: { position: { x: 440, y: 160 }, rotation: 90 },
        GND1: { position: { x: 260, y: 380 }, rotation: 0 },
      },
    },
  };
}

function divider(): { electrical: CircuitElectrical; visual: CircuitVisual } {
  return {
    electrical: {
      components: [
        { id: "V1", type: "dc_voltage_source", parameters: { voltage_v: 5 } },
        { id: "R1", type: "resistor", parameters: { resistance_ohms: 10000 } },
        { id: "R2", type: "resistor", parameters: { resistance_ohms: 10000 } },
        { id: "GND1", type: "ground", parameters: {} },
      ],
      connections: [
        { id: "w1", from: { component_id: "V1", terminal: "positive" }, to: { component_id: "R1", terminal: "a" } },
        { id: "w2", from: { component_id: "R1", terminal: "b" }, to: { component_id: "R2", terminal: "a" } },
        { id: "w3", from: { component_id: "R2", terminal: "b" }, to: { component_id: "GND1", terminal: "gnd" } },
        { id: "w4", from: { component_id: "V1", terminal: "negative" }, to: { component_id: "GND1", terminal: "gnd" } },
      ],
      targets: [{ id: "t1", metric: "voltage", component_id: "R2", target: 2.5, tolerance_pct: 5 }],
    },
    visual: {
      components: {
        V1: { position: { x: 60, y: 160 }, rotation: 90 },
        R1: { position: { x: 220, y: 40 }, rotation: 0 },
        R2: { position: { x: 440, y: 160 }, rotation: 90 },
        GND1: { position: { x: 260, y: 380 }, rotation: 0 },
      },
    },
  };
}

export function createFromTemplate(template: TemplateId, name?: string): CircuitDocument {
  const now = new Date().toISOString();
  const body =
    template === "led_series_resistor"
      ? led()
      : template === "voltage_divider"
        ? divider()
        : { electrical: { components: [], connections: [], targets: [] }, visual: { components: {} } };
  return {
    id: newId("circuit"),
    name: name ?? TEMPLATES.find((t) => t.id === template)?.name ?? "Untitled circuit",
    template,
    version: 1,
    createdAt: now,
    updatedAt: now,
    ...body,
  };
}
