import { getDef, validateParam } from "./catalog";
import { terminalKey, type CircuitElectrical, type ComponentType, type TerminalRef } from "./types";

export const GROUND_NET = "0";

export interface NetMap {
  /** terminal key ("R1:a") → net name ("N1" or "0"). Unconnected terminals get their own net. */
  netOf: Map<string, string>;
  /** net name → terminals on it. */
  members: Map<string, TerminalRef[]>;
}

/** Group connected terminals into nets (union-find). Deterministic naming in component order. */
export function computeNets(e: CircuitElectrical): NetMap {
  const parent = new Map<string, string>();
  const find = (k: string): string => {
    let r = k;
    while (parent.get(r) !== r) r = parent.get(r) ?? r;
    let c = k;
    while (parent.get(c) !== r) {
      const n = parent.get(c) ?? r;
      parent.set(c, r);
      c = n;
    }
    return r;
  };
  const order: TerminalRef[] = [];
  for (const comp of e.components) {
    for (const t of getDef(comp.type).terminals) {
      const ref = { component_id: comp.id, terminal: t.id };
      parent.set(terminalKey(ref), terminalKey(ref));
      order.push(ref);
    }
  }
  for (const w of e.connections) {
    const a = terminalKey(w.from);
    const b = terminalKey(w.to);
    if (!parent.has(a) || !parent.has(b)) continue;
    const ra = find(a);
    const rb = find(b);
    if (ra !== rb) parent.set(ra, rb);
  }
  const groundRoots = new Set<string>();
  for (const comp of e.components) {
    if (comp.type === "ground") groundRoots.add(find(`${comp.id}:gnd`));
  }
  const rootName = new Map<string, string>();
  let n = 1;
  const netOf = new Map<string, string>();
  const members = new Map<string, TerminalRef[]>();
  for (const ref of order) {
    const root = find(terminalKey(ref));
    let name = rootName.get(root);
    if (!name) {
      name = groundRoots.has(root) ? GROUND_NET : `N${n++}`;
      rootName.set(root, name);
    }
    netOf.set(terminalKey(ref), name);
    const list = members.get(name) ?? [];
    list.push(ref);
    members.set(name, list);
  }
  return { netOf, members };
}

export interface ValidationIssue {
  id: string;
  severity: "error" | "warning";
  code:
    | "empty"
    | "unsupported_component"
    | "invalid_parameter"
    | "unconnected_terminal"
    | "no_ground"
    | "no_source"
    | "shorted_component"
    | "floating"
    | "self_connection"
    | "duplicate_connection"
    | "unknown_terminal"
    | "invalid_target"
    | "backend_unsupported";
  message: string;
  component_id?: string;
  connection_id?: string;
  terminal?: string;
}

export interface ValidationOptions {
  /** Component types the connected backend reports as supported (from /health). */
  backendSupportedTypes?: string[] | null;
}

/**
 * Local structural validation before any request is sent.
 * This checks topology and parameter ranges only — it does not model electrical behaviour.
 */
export function validateCircuit(e: CircuitElectrical, opts: ValidationOptions = {}): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const add = (i: Omit<ValidationIssue, "id">) => issues.push({ id: `${i.code}:${i.component_id ?? ""}:${i.connection_id ?? ""}:${i.terminal ?? ""}`, ...i });

  if (e.components.length === 0) {
    add({ severity: "error", code: "empty", message: "Add components from the library to build a circuit." });
    return issues;
  }

  const ids = new Set(e.components.map((c) => c.id));
  const types = new Map(e.components.map((c) => [c.id, c.type] as [string, ComponentType]));

  for (const c of e.components) {
    const def = getDef(c.type);
    if (def.simulation !== "supported") {
      add({ severity: "error", code: "unsupported_component", component_id: c.id, message: `${c.id}: ${def.name} is not yet supported by the simulation engine.` });
    } else if (opts.backendSupportedTypes && c.type !== "ground" && !opts.backendSupportedTypes.includes(c.type)) {
      add({ severity: "error", code: "backend_unsupported", component_id: c.id, message: `${c.id}: the connected backend does not list "${c.type}" as supported.` });
    }
    for (const p of def.params) {
      const err = validateParam(p, c.parameters[p.key]);
      if (err) add({ severity: "error", code: "invalid_parameter", component_id: c.id, message: `${c.id}: ${err}.` });
    }
  }

  const seenPairs = new Set<string>();
  for (const w of e.connections) {
    for (const end of [w.from, w.to]) {
      const t = types.get(end.component_id);
      if (!t || !getDef(t).terminals.some((x) => x.id === end.terminal)) {
        add({ severity: "error", code: "unknown_terminal", connection_id: w.id, message: `Wire ${w.id} points to a missing terminal.` });
      }
    }
    if (w.from.component_id === w.to.component_id) {
      add({ severity: "error", code: "self_connection", connection_id: w.id, component_id: w.from.component_id, message: `${w.from.component_id} is wired to itself (short).` });
    }
    const pair = [terminalKey(w.from), terminalKey(w.to)].sort().join("|");
    if (seenPairs.has(pair)) add({ severity: "warning", code: "duplicate_connection", connection_id: w.id, message: `Wire ${w.id} duplicates another wire.` });
    seenPairs.add(pair);
  }

  const connected = new Set<string>();
  for (const w of e.connections) {
    connected.add(terminalKey(w.from));
    connected.add(terminalKey(w.to));
  }
  for (const c of e.components) {
    for (const t of getDef(c.type).terminals) {
      if (!connected.has(`${c.id}:${t.id}`)) {
        add({ severity: "error", code: "unconnected_terminal", component_id: c.id, terminal: t.id, message: `${c.id} terminal ${t.label} is not connected.` });
      }
    }
  }

  if (!e.components.some((c) => c.type === "ground")) {
    add({ severity: "error", code: "no_ground", message: "Add a ground symbol — the simulator needs a reference node." });
  }
  if (!e.components.some((c) => c.type === "dc_voltage_source")) {
    add({ severity: "error", code: "no_source", message: "Add a DC voltage source." });
  }

  const { netOf } = computeNets(e);
  for (const c of e.components) {
    const terms = getDef(c.type).terminals;
    if (terms.length !== 2) continue;
    const a = netOf.get(`${c.id}:${terms[0]!.id}`);
    const b = netOf.get(`${c.id}:${terms[1]!.id}`);
    const bothWired = connected.has(`${c.id}:${terms[0]!.id}`) && connected.has(`${c.id}:${terms[1]!.id}`);
    if (bothWired && a === b) {
      add({ severity: "error", code: "shorted_component", component_id: c.id, message: `${c.id} is shorted — both terminals are on the same node.` });
    }
  }

  // Floating groups: parts that share no path to the ground net.
  if (e.components.some((c) => c.type === "ground")) {
    const adj = new Map<string, Set<string>>();
    const byNet = new Map<string, Set<string>>();
    for (const c of e.components) {
      for (const t of getDef(c.type).terminals) {
        const net = netOf.get(`${c.id}:${t.id}`)!;
        const s = byNet.get(net) ?? new Set<string>();
        s.add(c.id);
        byNet.set(net, s);
      }
    }
    for (const s of byNet.values()) for (const a of s) for (const b of s) if (a !== b) (adj.get(a) ?? adj.set(a, new Set()).get(a)!).add(b);
    const reach = new Set<string>();
    const stack = e.components.filter((c) => c.type === "ground").map((c) => c.id);
    while (stack.length) {
      const id = stack.pop()!;
      if (reach.has(id)) continue;
      reach.add(id);
      for (const n of adj.get(id) ?? []) stack.push(n);
    }
    for (const c of e.components) {
      if (!reach.has(c.id)) add({ severity: "error", code: "floating", component_id: c.id, message: `${c.id} has no path to ground.` });
    }
  }

  for (const t of e.targets) {
    if (!ids.has(t.component_id)) add({ severity: "error", code: "invalid_target", message: `Target refers to missing part ${t.component_id}.` });
    else if (!(t.tolerance_pct > 0) || !Number.isFinite(t.target)) add({ severity: "error", code: "invalid_target", message: `Target on ${t.component_id} needs a value and a tolerance above 0 %.` });
  }

  return issues;
}

export const hasErrors = (issues: ValidationIssue[]) => issues.some((i) => i.severity === "error");

/** Next free reference designator for a type, e.g. R3. */
export function nextDesignator(e: CircuitElectrical, prefix: string): string {
  let i = 1;
  const ids = new Set(e.components.map((c) => c.id));
  while (ids.has(`${prefix}${i}`)) i++;
  return `${prefix}${i}`;
}
