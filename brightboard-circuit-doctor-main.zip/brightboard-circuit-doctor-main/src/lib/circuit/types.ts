/**
 * Frontend circuit data model.
 *
 * Electrical data (what gets simulated) and visual data (where things are drawn)
 * are stored in separate trees so that changing positions, rotation, colours or
 * animation settings can never alter what is sent to the simulator.
 */

export type ComponentType =
  | "dc_voltage_source"
  | "ground"
  | "resistor"
  | "led"
  | "capacitor"
  | "inductor"
  | "diode"
  | "switch";

export type ParamValue = number | string | boolean;

/** Electrical component — stable id, type and electrical parameters only. */
export interface ElectricalComponent {
  id: string;
  type: ComponentType;
  parameters: Record<string, ParamValue>;
}

export interface TerminalRef {
  component_id: string;
  terminal: string;
}

/** A wire between two terminals. */
export interface Connection {
  id: string;
  from: TerminalRef;
  to: TerminalRef;
}

export type TargetMetric = "current" | "voltage" | "power";

/** Acceptance criterion sent to the backend, which evaluates it against simulated values. */
export interface TargetCriterion {
  id: string;
  metric: TargetMetric;
  component_id: string;
  /** SI units: A, V or W. */
  target: number;
  tolerance_pct: number;
}

export interface CircuitElectrical {
  components: ElectricalComponent[];
  connections: Connection[];
  targets: TargetCriterion[];
}

export type Rotation = 0 | 90 | 180 | 270;

/** Visual-only metadata for one component. Never sent to the simulator. */
export interface ComponentVisual {
  position: { x: number; y: number };
  rotation: Rotation;
}

export interface CircuitVisual {
  components: Record<string, ComponentVisual>;
}

export type TemplateId = "led_series_resistor" | "voltage_divider" | "empty";

export interface CircuitDocument {
  id: string;
  name: string;
  template: TemplateId;
  /** Incremented every time a changed electrical model is saved. */
  version: number;
  createdAt: string;
  updatedAt: string;
  electrical: CircuitElectrical;
  visual: CircuitVisual;
}

export const terminalKey = (ref: TerminalRef) => `${ref.component_id}:${ref.terminal}`;
