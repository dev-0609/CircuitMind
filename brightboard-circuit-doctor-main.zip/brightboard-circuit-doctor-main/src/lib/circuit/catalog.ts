import type { ComponentType, ParamValue } from "./types";

export type ParamDef =
  | {
      key: string;
      label: string;
      kind: "number";
      unit: string;
      default: number;
      /** Exclusive lower bound. */
      greaterThan?: number;
      max?: number;
      hint?: string;
    }
  | { key: string; label: string; kind: "enum"; options: { value: string; label: string }[]; default: string; hint?: string }
  | { key: string; label: string; kind: "boolean"; default: boolean; hint?: string };

export interface TerminalDef {
  id: string;
  label: string;
}

export type SimulationSupport = "supported" | "planned";

export interface ComponentDef {
  type: ComponentType;
  name: string;
  category: "power" | "passive" | "semiconductor" | "other";
  /** Reference designator prefix, e.g. R → R1. */
  prefix: string;
  /** Whether the frontend lets users add it for simulation. Planned parts are shown but disabled. */
  simulation: SimulationSupport;
  /**
   * Terminal order matters: the backend current sign convention is
   * "positive = conventional current entering terminals[0] and leaving terminals[1]".
   */
  terminals: TerminalDef[];
  params: ParamDef[];
  description: string;
  /** Tailwind text colour token for the symbol stroke. */
  tone: string;
}

export const CATEGORY_LABEL: Record<ComponentDef["category"], string> = {
  power: "Power",
  passive: "Passive",
  semiconductor: "Semiconductors",
  other: "Other",
};

export const CATALOG: ComponentDef[] = [
  {
    type: "dc_voltage_source",
    name: "DC voltage source",
    category: "power",
    prefix: "V",
    simulation: "supported",
    terminals: [
      { id: "positive", label: "+" },
      { id: "negative", label: "−" },
    ],
    params: [{ key: "voltage_v", label: "Voltage", kind: "number", unit: "V", default: 5, greaterThan: 0, max: 1000 }],
    description: "Ideal DC supply.",
    tone: "text-electric",
  },
  {
    type: "ground",
    name: "Ground",
    category: "power",
    prefix: "GND",
    simulation: "supported",
    terminals: [{ id: "gnd", label: "GND" }],
    params: [],
    description: "Reference node 0. Not sent as a part; its net becomes node \"0\".",
    tone: "text-muted-foreground",
  },
  {
    type: "resistor",
    name: "Resistor",
    category: "passive",
    prefix: "R",
    simulation: "supported",
    terminals: [
      { id: "a", label: "1" },
      { id: "b", label: "2" },
    ],
    params: [
      { key: "resistance_ohms", label: "Resistance", kind: "number", unit: "Ω", default: 330, greaterThan: 0, max: 1e9 },
    ],
    description: "Limits current.",
    tone: "text-role-resistor",
  },
  {
    type: "led",
    name: "LED",
    category: "semiconductor",
    prefix: "D",
    simulation: "supported",
    terminals: [
      { id: "anode", label: "A" },
      { id: "cathode", label: "K" },
    ],
    params: [
      {
        key: "model",
        label: "Device model",
        kind: "enum",
        options: [{ value: "default", label: "Backend default LED model" }],
        default: "default",
        hint: "Model names must be agreed with the backend before more are offered.",
      },
    ],
    description: "Light-emitting diode. Forward voltage comes from the backend model.",
    tone: "text-role-diode",
  },
  {
    type: "capacitor",
    name: "Capacitor",
    category: "passive",
    prefix: "C",
    simulation: "planned",
    terminals: [
      { id: "a", label: "1" },
      { id: "b", label: "2" },
    ],
    params: [{ key: "capacitance_f", label: "Capacitance", kind: "number", unit: "F", default: 1e-6, greaterThan: 0 }],
    description: "Stores charge.",
    tone: "text-role-capacitor",
  },
  {
    type: "inductor",
    name: "Inductor",
    category: "passive",
    prefix: "L",
    simulation: "planned",
    terminals: [
      { id: "a", label: "1" },
      { id: "b", label: "2" },
    ],
    params: [{ key: "inductance_h", label: "Inductance", kind: "number", unit: "H", default: 1e-3, greaterThan: 0 }],
    description: "Stores energy in a magnetic field.",
    tone: "text-role-inductor",
  },
  {
    type: "diode",
    name: "Diode",
    category: "semiconductor",
    prefix: "D",
    simulation: "planned",
    terminals: [
      { id: "anode", label: "A" },
      { id: "cathode", label: "K" },
    ],
    params: [],
    description: "One-way current flow.",
    tone: "text-role-diode",
  },
  {
    type: "switch",
    name: "Switch",
    category: "other",
    prefix: "S",
    simulation: "planned",
    terminals: [
      { id: "a", label: "1" },
      { id: "b", label: "2" },
    ],
    params: [{ key: "closed", label: "Closed", kind: "boolean", default: true }],
    description: "Opens or closes a branch.",
    tone: "text-foreground",
  },
];

const BY_TYPE = new Map(CATALOG.map((d) => [d.type, d]));

export function getDef(type: ComponentType): ComponentDef {
  const def = BY_TYPE.get(type);
  if (!def) throw new Error(`Unknown component type: ${type}`);
  return def;
}

export function defaultParams(type: ComponentType): Record<string, ParamValue> {
  const out: Record<string, ParamValue> = {};
  for (const p of getDef(type).params) out[p.key] = p.default;
  return out;
}

/** Validate one parameter value against its definition. Returns an error message or null. */
export function validateParam(def: ParamDef, value: ParamValue | undefined): string | null {
  if (value === undefined) return `${def.label} is required`;
  if (def.kind === "number") {
    if (typeof value !== "number" || !Number.isFinite(value)) return `${def.label} must be a number`;
    if (def.greaterThan !== undefined && !(value > def.greaterThan)) return `${def.label} must be greater than ${def.greaterThan} ${def.unit}`;
    if (def.max !== undefined && value > def.max) return `${def.label} must be at most ${def.max} ${def.unit}`;
    return null;
  }
  if (def.kind === "enum") {
    return def.options.some((o) => o.value === value) ? null : `${def.label} has an unknown value`;
  }
  return typeof value === "boolean" ? null : `${def.label} must be on or off`;
}

/** The main numeric parameter of a part (used for fault injection and value labels). */
export function primaryNumericParam(type: ComponentType) {
  const p = getDef(type).params.find((x) => x.kind === "number");
  return p && p.kind === "number" ? p : null;
}
