import { useSyncExternalStore } from "react";

/** Shared scroll state read by the 3D scene every frame and by the page UI. */
export const circuitState = { progress: 0, section: 0 };

export const SECTIONS = [
  { id: "top", label: "Power on" },
  { id: "design", label: "Design" },
  { id: "simulate", label: "Simulate" },
  { id: "fault", label: "Break" },
  { id: "diagnose", label: "Diagnose" },
  { id: "repair", label: "Repair" },
  { id: "launch", label: "Launch" },
] as const;

const listeners = new Set<() => void>();

export function setSection(index: number) {
  if (index === circuitState.section) return;
  circuitState.section = index;
  listeners.forEach((l) => l());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function useSection() {
  return useSyncExternalStore(
    subscribe,
    () => circuitState.section,
    () => 0,
  );
}
