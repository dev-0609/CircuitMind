/** Component role colours — shared by the 3D scene (hex) and the legend (CSS tokens). */
export type PartType = "resistor" | "capacitor" | "transistor" | "inductor" | "diode" | "ic" | "led";

export const ROLE_HEX: Record<PartType, string> = {
  resistor: "#ff9f1c",
  capacitor: "#2de2ff",
  transistor: "#ff4fa3",
  inductor: "#c6ff3d",
  diode: "#ffe14d",
  ic: "#5b8cff",
  led: "#ffffff",
};

export const ROLES: { type: Exclude<PartType, "led">; name: string; job: string; swatch: string }[] = [
  { type: "resistor", name: "Resistor", job: "Limits current — glows with heat", swatch: "bg-role-resistor text-role-resistor" },
  { type: "capacitor", name: "Capacitor", job: "Stores charge — fills and drains", swatch: "bg-role-capacitor text-role-capacitor" },
  { type: "transistor", name: "Transistor", job: "Switches & amplifies — blinks on/off", swatch: "bg-role-transistor text-role-transistor" },
  { type: "inductor", name: "Inductor", job: "Holds a magnetic field — breathes", swatch: "bg-role-inductor text-role-inductor" },
  { type: "diode", name: "Diode", job: "One-way flow — lights half the cycle", swatch: "bg-role-diode text-role-diode" },
  { type: "ic", name: "Logic IC", job: "Processes signals — flickers with data", swatch: "bg-role-ic text-role-ic" },
];

/** Signal colour of the whole board for each page section. */
export const MODE_HEX = ["#a8ecff", "#5b8cff", "#39ff88", "#ff3b30", "#ffb020", "#39ff88", "#a8ecff"];
