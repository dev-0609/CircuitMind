/** Engineering-notation parsing and formatting for electrical values. Pure, no electrical modelling. */

const PREFIXES: Record<string, number> = {
  p: 1e-12,
  n: 1e-9,
  u: 1e-6,
  µ: 1e-6,
  m: 1e-3,
  "": 1,
  k: 1e3,
  K: 1e3,
  M: 1e6,
  G: 1e9,
};

/**
 * Parse values like "330", "4.7k", "2k2", "10m", "1e-3", "330 Ω", "5V".
 * Returns null when the text is not a finite number.
 */
export function parseEngineering(input: string): number | null {
  const text = input.trim().replace(/\s+/g, "").replace(/[ΩΩVAFHWvafhw]|ohms?$/gi, "");
  if (!text) return null;
  // 2k2 / 4R7 style
  const infix = /^(\d+)([pnuµmkKMGR])(\d+)$/.exec(text);
  if (infix) {
    const [, a, p, b] = infix;
    const mult = p === "R" ? 1 : (PREFIXES[p ?? ""] ?? NaN);
    const v = Number(`${a}.${b}`) * mult;
    return Number.isFinite(v) ? v : null;
  }
  const m = /^([-+]?\d*\.?\d+(?:e[-+]?\d+)?)([pnuµmkKMG]?)$/i.exec(text);
  if (!m) return null;
  const [, num, prefix] = m;
  // "M" (mega) vs "m" (milli) are case-sensitive; the /i flag only affects the exponent
  const mult = PREFIXES[prefix ?? ""];
  if (mult === undefined) return null;
  const v = Number(num) * mult;
  return Number.isFinite(v) ? v : null;
}

const FORMAT_STEPS: [number, string][] = [
  [1e9, "G"],
  [1e6, "M"],
  [1e3, "k"],
  [1, ""],
  [1e-3, "m"],
  [1e-6, "µ"],
  [1e-9, "n"],
  [1e-12, "p"],
];

/** Format a value with an SI prefix: 0.00933, "A" → "9.33 mA". */
export function formatSI(value: number | null | undefined, unit: string, digits = 3): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return "—";
  if (value === 0) return `0 ${unit}`;
  const abs = Math.abs(value);
  const step = FORMAT_STEPS.find(([f]) => abs >= f) ?? FORMAT_STEPS[FORMAT_STEPS.length - 1]!;
  const scaled = value / step[0];
  const str = Number(scaled.toPrecision(digits)).toString();
  return `${str} ${step[1]}${unit}`;
}

export function formatPercent(value: number | null | undefined, digits = 1): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return "—";
  const sign = value > 0 ? "+" : "";
  return `${sign}${value.toFixed(digits)}%`;
}

/** Relative change in percent, or null when the reference is zero/missing. */
export function percentChange(from: number | null | undefined, to: number | null | undefined): number | null {
  if (from === null || from === undefined || to === null || to === undefined) return null;
  if (from === 0) return null;
  return ((to - from) / Math.abs(from)) * 100;
}
