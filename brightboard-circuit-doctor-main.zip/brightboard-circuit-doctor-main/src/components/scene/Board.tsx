import { useMemo } from "react";
import * as THREE from "three";
import { BOARD, mulberry32 } from "./layout";

function makeBoardTexture() {
  const size = 1024;
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const g = c.getContext("2d")!;
  const rng = mulberry32(3);

  // matte black-green solder mask with mottled variation
  g.fillStyle = "#0b1412";
  g.fillRect(0, 0, size, size);
  for (let i = 0; i < 1400; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const r = 6 + rng() * 40;
    const grad = g.createRadialGradient(x, y, 0, x, y, r);
    const tone = rng() < 0.5 ? "16,30,26" : "6,12,11";
    grad.addColorStop(0, `rgba(${tone},0.35)`);
    grad.addColorStop(1, `rgba(${tone},0)`);
    g.fillStyle = grad;
    g.fillRect(x - r, y - r, r * 2, r * 2);
  }

  // fine dot grid
  g.fillStyle = "rgba(120,170,150,0.10)";
  for (let y = 8; y < size; y += 32) for (let x = 8; x < size; x += 32) g.fillRect(x, y, 2, 2);

  // silkscreen outlines + labels
  g.strokeStyle = "rgba(220,225,215,0.22)";
  g.fillStyle = "rgba(220,225,215,0.28)";
  g.lineWidth = 2;
  g.font = "600 16px monospace";
  const labels = ["R", "C", "Q", "D", "U", "L", "TP", "J"];
  for (let i = 0; i < 46; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const w = 30 + rng() * 90;
    const h = 20 + rng() * 50;
    g.strokeRect(x, y, w, h);
    g.fillText(`${labels[Math.floor(rng() * labels.length)]}${1 + Math.floor(rng() * 48)}`, x + 4, y - 6);
  }

  // copper-ringed vias
  for (let i = 0; i < 160; i++) {
    const x = rng() * size;
    const y = rng() * size;
    g.beginPath();
    g.arc(x, y, 4 + rng() * 3, 0, Math.PI * 2);
    g.fillStyle = "rgba(170,120,70,0.55)";
    g.fill();
    g.beginPath();
    g.arc(x, y, 1.8, 0, Math.PI * 2);
    g.fillStyle = "#020303";
    g.fill();
  }

  // faint inner-layer traces under the mask
  g.strokeStyle = "rgba(40,70,60,0.45)";
  g.lineWidth = 3;
  for (let i = 0; i < 70; i++) {
    let x = rng() * size;
    let y = rng() * size;
    g.beginPath();
    g.moveTo(x, y);
    for (let s = 0; s < 4; s++) {
      if (rng() < 0.5) x += (rng() - 0.5) * 300;
      else y += (rng() - 0.5) * 300;
      g.lineTo(x, y);
    }
    g.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 8;
  return tex;
}

export function Board() {
  const length = BOARD.zStart - BOARD.zEnd;
  const width = BOARD.halfWidth * 2;
  const texture = useMemo(() => {
    const t = makeBoardTexture();
    t.repeat.set(width / 22, length / 22);
    return t;
  }, [length, width]);

  return (
    <mesh rotation-x={-Math.PI / 2} position={[0, 0, (BOARD.zStart + BOARD.zEnd) / 2]}>
      <planeGeometry args={[width, length]} />
      <meshStandardMaterial map={texture} roughness={0.78} metalness={0.15} color="#9fb3ab" />
    </mesh>
  );
}
