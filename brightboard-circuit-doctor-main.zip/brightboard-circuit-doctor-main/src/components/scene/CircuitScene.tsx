import { Environment, Lightformer } from "@react-three/drei";
import { Canvas } from "@react-three/fiber";
import { Bloom, EffectComposer, Vignette } from "@react-three/postprocessing";
import { Arcs } from "./Arcs";
import { Board } from "./Board";
import { Dust } from "./Dust";
import { HeroChip } from "./HeroChip";
import { CameraRig, Director, ModeEffects } from "./ModeEffects";
import { Parts } from "./Parts";
import { Traces } from "./Traces";

const BG = "#040708";

export default function CircuitScene() {
  return (
    <Canvas
      dpr={[1, 1.75]}
      gl={{ antialias: false, powerPreference: "high-performance" }}
      camera={{ position: [0, 7.5, 15], fov: 50, near: 0.1, far: 140 }}
    >
      <Director />
      <color attach="background" args={[BG]} />
      <fogExp2 attach="fog" args={[BG, 0.024]} />
      <ambientLight intensity={0.22} />
      <hemisphereLight args={["#9fc9ff", "#1a0f08", 0.35]} />
      <directionalLight position={[8, 14, 6]} intensity={1.1} color="#ffe2c2" />
      <Environment resolution={64} frames={1}>
        <Lightformer intensity={2.2} position={[0, 6, 0]} rotation-x={Math.PI / 2} scale={[12, 12, 1]} />
        <Lightformer intensity={1.4} color="#ffb070" position={[-6, 2, -2]} rotation-y={Math.PI / 2} scale={[20, 1.5, 1]} />
        <Lightformer intensity={1.2} color="#7fd8ff" position={[6, 2, 2]} rotation-y={-Math.PI / 2} scale={[20, 1.5, 1]} />
      </Environment>

      <Board />
      <Traces />
      <Parts />
      <HeroChip />
      <Arcs />
      <Dust />
      <ModeEffects />
      <CameraRig />

      <EffectComposer multisampling={0}>
        <Bloom mipmapBlur luminanceThreshold={0.7} luminanceSmoothing={0.3} intensity={1.25} radius={0.72} />
        <Vignette offset={0.22} darkness={0.78} />
      </EffectComposer>
    </Canvas>
  );
}
