import { useFrame } from "@react-three/fiber";
import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { getTraces, mulberry32, type V2 } from "./layout";
import { live } from "./live";

interface TraceData {
  pts: V2[];
  cum: number[];
  total: number;
}

interface Pulse {
  trace: number;
  s0: number;
  speed: number;
  len: number;
}

export function Traces() {
  const traces = useMemo<TraceData[]>(
    () =>
      getTraces().map((pts) => {
        const cum = [0];
        for (let i = 1; i < pts.length; i++) {
          const a = pts[i - 1]!;
          const b = pts[i]!;
          cum.push(cum[i - 1]! + Math.hypot(b[0] - a[0], b[1] - a[1]));
        }
        return { pts, cum, total: cum[cum.length - 1]! };
      }),
    [],
  );

  const segCount = useMemo(() => traces.reduce((n, t) => n + t.pts.length - 1, 0), [traces]);
  const padCount = traces.length * 2;

  const pulses = useMemo<Pulse[]>(() => {
    const rng = mulberry32(99);
    const list: Pulse[] = [];
    traces.forEach((t, i) => {
      const n = 1 + Math.floor(t.total / 28);
      for (let k = 0; k < n; k++) {
        list.push({ trace: i, s0: rng() * t.total, speed: 3 + rng() * 7, len: 0.6 + rng() * 0.9 });
      }
    });
    return list;
  }, [traces]);

  const segRef = useRef<THREE.InstancedMesh>(null);
  const padRef = useRef<THREE.InstancedMesh>(null);
  const pulseRef = useRef<THREE.InstancedMesh>(null);

  const boxGeo = useMemo(() => new THREE.BoxGeometry(1, 1, 1), []);
  const padGeo = useMemo(() => new THREE.CylinderGeometry(0.17, 0.17, 0.035, 14), []);
  const pulseGeo = useMemo(() => new THREE.BoxGeometry(0.08, 0.03, 1), []);
  const pulseMat = useMemo(
    () =>
      new THREE.MeshBasicMaterial({
        toneMapped: false,
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    [],
  );

  useLayoutEffect(() => {
    const d = new THREE.Object3D();
    let s = 0;
    let p = 0;
    for (const t of traces) {
      for (let i = 1; i < t.pts.length; i++) {
        const [ax, az] = t.pts[i - 1]!;
        const [bx, bz] = t.pts[i]!;
        const len = Math.hypot(bx - ax, bz - az);
        d.position.set((ax + bx) / 2, 0.012, (az + bz) / 2);
        d.rotation.set(0, Math.atan2(bx - ax, bz - az), 0);
        d.scale.set(0.11, 0.018, len + 0.11);
        d.updateMatrix();
        segRef.current?.setMatrixAt(s++, d.matrix);
      }
      for (const [x, z] of [t.pts[0]!, t.pts[t.pts.length - 1]!]) {
        d.position.set(x, 0.018, z);
        d.rotation.set(0, 0, 0);
        d.scale.set(1, 1, 1);
        d.updateMatrix();
        padRef.current?.setMatrixAt(p++, d.matrix);
      }
    }
    if (segRef.current) segRef.current.instanceMatrix.needsUpdate = true;
    if (padRef.current) padRef.current.instanceMatrix.needsUpdate = true;
  }, [traces]);

  const dummy = useMemo(() => new THREE.Object3D(), []);

  useFrame(({ clock }) => {
    const mesh = pulseRef.current;
    if (!mesh) return;
    const t = clock.elapsedTime;
    const speedMul = 1 + live.sim * 1.6 + live.repair * 0.4 - live.fault * 0.55;
    pulses.forEach((pl, i) => {
      const tr = traces[pl.trace]!;
      let s = (pl.s0 + t * pl.speed * speedMul) % tr.total;
      // in fault mode, some pulses stall and jitter like a broken path
      if (live.fault > 0.3 && i % 3 === 0) s = (pl.s0 + Math.sin(t * 20 + i) * 0.4 + tr.total) % tr.total;
      let k = 1;
      while (k < tr.cum.length - 1 && tr.cum[k]! < s) k++;
      const a = tr.pts[k - 1]!;
      const b = tr.pts[k]!;
      const c0 = tr.cum[k - 1]!;
      const segLen = tr.cum[k]! - c0 || 1;
      const u = (s - c0) / segLen;
      dummy.position.set(a[0] + (b[0] - a[0]) * u, 0.05, a[1] + (b[1] - a[1]) * u);
      dummy.rotation.set(0, Math.atan2(b[0] - a[0], b[1] - a[1]), 0);
      dummy.scale.set(1, 1, pl.len * (0.8 + speedMul * 0.4));
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
    pulseMat.color.copy(live.color).multiplyScalar(3.2 * live.power * live.flicker);
  });

  return (
    <group>
      <instancedMesh ref={segRef} args={[boxGeo, undefined, segCount]} frustumCulled={false}>
        <meshStandardMaterial color="#b06a34" metalness={0.85} roughness={0.38} />
      </instancedMesh>
      <instancedMesh ref={padRef} args={[padGeo, undefined, padCount]} frustumCulled={false}>
        <meshStandardMaterial color="#d9d1bf" metalness={1} roughness={0.25} />
      </instancedMesh>
      <instancedMesh ref={pulseRef} args={[pulseGeo, pulseMat, pulses.length]} frustumCulled={false} />
    </group>
  );
}
