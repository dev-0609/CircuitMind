import * as THREE from "three";
import { circuitState } from "@/lib/circuit-store";
import { MODE_HEX } from "@/lib/circuit-palette";

const MODE_COLORS = MODE_HEX.map((c) => new THREE.Color(c));

/** Per-frame scene state derived from scroll. Mutated in place, never via React state. */
export const live = {
  color: new THREE.Color(MODE_HEX[0]),
  power: 0,
  design: 0,
  sim: 0,
  fault: 0,
  diag: 0,
  repair: 0,
  flicker: 1,
  progress: 0,
};

export function updateLive(dt: number) {
  const s = circuitState.section;
  const k = 1 - Math.exp(-3 * dt);
  live.color.lerp(MODE_COLORS[s] ?? MODE_COLORS[0]!, k);
  live.power += (1 - live.power) * (1 - Math.exp(-0.8 * dt));
  live.design += ((s === 1 ? 1 : 0) - live.design) * k;
  live.sim += ((s === 2 ? 1 : 0) - live.sim) * k;
  live.fault += ((s === 3 ? 1 : 0) - live.fault) * k;
  live.diag += ((s === 4 ? 1 : 0) - live.diag) * k;
  live.repair += ((s === 5 || s === 6 ? 1 : 0) - live.repair) * k;
  live.progress += (circuitState.progress - live.progress) * (1 - Math.exp(-4 * dt));
  live.flicker = live.fault > 0.05 && Math.random() < 0.14 * live.fault ? 0.12 + Math.random() * 0.3 : 1;
}
