import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { HERO_CHIP } from "./layout";
import { live } from "./live";

/** The "mind": a large processor at the start of the board with a holographic halo. */
export function HeroChip() {
  const { size } = HERO_CHIP;
  const pins = useMemo(() => {
    const gs: THREE.BufferGeometry[] = [];
    const n = 16;
    for (let i = 0; i < n; i++) {
      const t = -size / 2 + 0.35 + (i / (n - 1)) * (size - 0.7);
      for (const [x, z, ry] of [
        [t, size / 2 + 0.2, 0],
        [t, -size / 2 - 0.2, 0],
        [size / 2 + 0.2, t, Math.PI / 2],
        [-size / 2 - 0.2, t, Math.PI / 2],
      ] as const) {
        const g = new THREE.BoxGeometry(0.09, 0.05, 0.45).toNonIndexed();
        g.deleteAttribute("uv");
        g.rotateY(ry);
        g.translate(x, 0.08, z);
        gs.push(g);
      }
    }
    return mergeGeometries(gs)!;
  }, [size]);

  const core = useRef<THREE.MeshBasicMaterial>(null);
  const frame = useRef<THREE.MeshBasicMaterial>(null);
  const rings = useRef<THREE.Group>(null);
  const ringMat = useMemo(
    () =>
      new THREE.MeshBasicMaterial({
        toneMapped: false,
        transparent: true,
        opacity: 0.8,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    [],
  );
  const white = useMemo(() => new THREE.Color("#ffffff"), []);

  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    // heartbeat: two quick pulses then rest
    const beat = Math.max(0, Math.sin(t * 5)) ** 8 + Math.max(0, Math.sin(t * 5 - 0.9)) ** 8;
    const p = live.power * live.flicker;
    core.current?.color.copy(live.color).lerp(white, 0.35).multiplyScalar((1.6 + beat * 3) * p);
    frame.current?.color.copy(live.color).multiplyScalar(2.2 * p);
    ringMat.color.copy(live.color).multiplyScalar(1.8 * p);
    if (rings.current) {
      rings.current.children.forEach((r, i) => {
        r.rotation.z = t * (0.25 + i * 0.18) * (i % 2 ? -1 : 1);
        r.position.y = 1.4 + i * 0.55 + Math.sin(t * 1.2 + i) * 0.08;
      });
    }
  });

  return (
    <group position={[HERO_CHIP.x, 0, HERO_CHIP.z]}>
      <mesh position={[0, 0.3, 0]}>
        <boxGeometry args={[size, 0.45, size]} />
        <meshStandardMaterial color="#0e1013" roughness={0.42} metalness={0.25} />
      </mesh>
      <mesh geometry={pins}>
        <meshStandardMaterial color="#d6d9dd" metalness={1} roughness={0.25} />
      </mesh>
      {/* die window + frame */}
      <mesh position={[0, 0.53, 0]} rotation-x={-Math.PI / 2}>
        <planeGeometry args={[1.5, 1.5]} />
        <meshBasicMaterial ref={core} toneMapped={false} />
      </mesh>
      <mesh position={[0, 0.531, 0]} rotation-x={-Math.PI / 2}>
        <ringGeometry args={[1.25, 1.32, 4, 1, Math.PI / 4]} />
        <meshBasicMaterial ref={frame} toneMapped={false} />
      </mesh>
      <mesh position={[-size / 2 + 0.45, 0.53, size / 2 - 0.45]} rotation-x={-Math.PI / 2}>
        <circleGeometry args={[0.12, 16]} />
        <meshBasicMaterial color="#3a3f45" />
      </mesh>
      <group ref={rings}>
        {[1.7, 2.3, 2.9].map((r, i) => (
          <mesh key={r} rotation-x={-Math.PI / 2} material={ringMat}>
            <ringGeometry args={[r, r + 0.03, 96, 1, 0, Math.PI * (1.2 + i * 0.25)]} />
          </mesh>
        ))}
      </group>
    </group>
  );
}
