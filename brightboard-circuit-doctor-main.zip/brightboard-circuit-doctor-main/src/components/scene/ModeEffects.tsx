import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { live, updateLive } from "./live";

/** Must be the first scene child so every other frame callback reads fresh state. */
export function Director() {
  useFrame((_, delta) => updateLive(Math.min(delta, 0.05)));
  return null;
}

/** Camera dolly driven by scroll, with mouse parallax and fault shake. */
export function CameraRig() {
  const light = useRef<THREE.PointLight>(null);
  const pos = useMemo(() => new THREE.Vector3(0, 7.5, 15), []);
  const look = useMemo(() => new THREE.Vector3(), []);

  useFrame(({ camera, pointer, clock }, delta) => {
    const dt = Math.min(delta, 0.05);
    const p = live.progress;
    const t = clock.elapsedTime;
    const z = 15 - p * 176;
    const x = Math.sin(p * Math.PI * 3) * 3.2 + pointer.x * 1.2;
    const y = 7.2 + Math.sin(p * Math.PI * 2.4) * 1.4 + pointer.y * 0.5 - live.diag * 1.2;
    pos.set(x, y, z);
    camera.position.lerp(pos, 1 - Math.exp(-5 * dt));
    if (live.fault > 0.05) {
      const s = live.fault * 0.09;
      camera.position.x += (Math.random() - 0.5) * s;
      camera.position.y += (Math.random() - 0.5) * s;
    }
    const heroLook = Math.max(0, 1 - p * 12);
    look.set(camera.position.x * 0.35 + heroLook * 2.5, 0, camera.position.z - 15 + Math.sin(t * 0.2) * 0.3);
    camera.lookAt(look);
    if (light.current) {
      light.current.position.set(camera.position.x, 3.2, camera.position.z - 9);
      light.current.color.copy(live.color);
      light.current.intensity = (14 + live.fault * 25 * live.flicker) * live.power;
    }
  });

  return <pointLight ref={light} distance={26} decay={1.6} />;
}

/** Section-specific board effects: blueprint grid, scan sweep, repair ripple. */
export function ModeEffects() {
  const grid = useRef<THREE.Mesh>(null);
  const scan = useRef<THREE.Mesh>(null);
  const ripple = useRef<THREE.Mesh>(null);

  const gridUniforms = useMemo(() => ({ uAmt: { value: 0 }, uTime: { value: 0 }, uColor: { value: new THREE.Color("#5b8cff") } }), []);
  const scanMat = useMemo(
    () =>
      new THREE.MeshBasicMaterial({
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide,
        toneMapped: false,
        map: (() => {
          const c = document.createElement("canvas");
          c.width = 4;
          c.height = 128;
          const g = c.getContext("2d")!;
          const gr = g.createLinearGradient(0, 0, 0, 128);
          gr.addColorStop(0, "rgba(255,255,255,0)");
          gr.addColorStop(0.85, "rgba(255,255,255,0.35)");
          gr.addColorStop(1, "rgba(255,255,255,1)");
          g.fillStyle = gr;
          g.fillRect(0, 0, 4, 128);
          return new THREE.CanvasTexture(c);
        })(),
      }),
    [],
  );
  const rippleMat = useMemo(
    () =>
      new THREE.MeshBasicMaterial({
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        toneMapped: false,
      }),
    [],
  );

  useFrame(({ camera, clock }) => {
    const t = clock.elapsedTime;
    const cz = camera.position.z;
    if (grid.current) {
      grid.current.position.z = cz - 25;
      grid.current.visible = live.design > 0.01;
      gridUniforms.uAmt.value = live.design;
      gridUniforms.uTime.value = t;
    }
    if (scan.current) {
      const cycle = (t * 0.45) % 1;
      scan.current.position.set(camera.position.x * 0.3, 0, cz - 4 - cycle * 34);
      scan.current.visible = live.diag > 0.01;
      scanMat.color.set("#ffb020").multiplyScalar(2.2 * live.diag);
      scanMat.opacity = live.diag;
    }
    if (ripple.current) {
      const cycle = (t * 0.35) % 1;
      ripple.current.position.set(camera.position.x * 0.3, 0.03, cz - 16);
      const s = 0.5 + cycle * 26;
      ripple.current.scale.set(s, s, s);
      ripple.current.visible = live.repair > 0.01;
      rippleMat.color.set("#39ff88").multiplyScalar(2.4 * live.repair * (1 - cycle));
    }
  });

  return (
    <group>
      <mesh ref={grid} rotation-x={-Math.PI / 2} position={[0, 0.035, 0]}>
        <planeGeometry args={[80, 60]} />
        <shaderMaterial
          uniforms={gridUniforms}
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
          vertexShader={/* glsl */ `
            varying vec2 vUv;
            void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
          `}
          fragmentShader={/* glsl */ `
            uniform float uAmt; uniform float uTime; uniform vec3 uColor;
            varying vec2 vUv;
            float line(vec2 uv, float n, float w) {
              vec2 g = abs(fract(uv * n - 0.5) - 0.5) / fwidth(uv * n);
              return 1.0 - min(min(g.x, g.y) / w, 1.0);
            }
            void main() {
              vec2 uv = vUv * vec2(80.0, 60.0) / 60.0;
              float l = line(uv, 30.0, 1.0) * 0.35 + line(uv, 6.0, 1.4) * 0.8;
              float wave = smoothstep(0.08, 0.0, abs(fract(vUv.y - uTime * 0.18) - 0.5));
              float fade = smoothstep(0.0, 0.25, vUv.x) * smoothstep(1.0, 0.75, vUv.x) * smoothstep(0.0, 0.3, vUv.y);
              gl_FragColor = vec4(uColor * (l * (0.6 + wave * 2.5)) * 1.6, l * uAmt * fade);
            }
          `}
        />
      </mesh>
      <mesh ref={scan} material={scanMat}>
        <planeGeometry args={[70, 3.2]} />
      </mesh>
      <mesh ref={ripple} rotation-x={-Math.PI / 2} material={rippleMat}>
        <ringGeometry args={[0.96, 1, 96]} />
      </mesh>
    </group>
  );
}
