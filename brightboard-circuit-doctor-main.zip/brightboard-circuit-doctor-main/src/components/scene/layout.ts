import type { PartType } from "@/lib/circuit-palette";

export function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const BOARD = { zStart: 22, zEnd: -205, halfWidth: 40 };
export const HERO_CHIP = { x: 6.5, z: -1, size: 4.4 };

export interface Part {
  type: PartType;
  x: number;
  z: number;
  rot: number;
  scale: number;
  phase: number;
  freq: number;
}

let partsCache: Part[] | null = null;

export function getParts(): Part[] {
  if (partsCache) return partsCache;
  const rng = mulberry32(7);
  const parts: Part[] = [];
  const cell = 3.1;
  for (let z = 14; z > -198; z -= cell) {
    for (let x = -27; x <= 27; x += cell) {
      const px = x + (rng() - 0.5) * 1.1;
      const pz = z + (rng() - 0.5) * 1.1;
      if (Math.abs(px - HERO_CHIP.x) < 4.6 && Math.abs(pz - HERO_CHIP.z) < 4.6) continue;
      const center = Math.abs(px) < 4.5;
      if (rng() > (center ? 0.26 : 0.62)) continue;
      const r = rng();
      const type: PartType =
        r < 0.26
          ? "resistor"
          : r < 0.44
            ? "capacitor"
            : r < 0.58
              ? "transistor"
              : r < 0.7
                ? "diode"
                : r < 0.81
                  ? "led"
                  : r < 0.89
                    ? "inductor"
                    : "ic";
      parts.push({
        type,
        x: px,
        z: pz,
        rot: rng() < 0.75 ? Math.round(rng() * 4) * (Math.PI / 2) : rng() * Math.PI * 2,
        scale: 0.9 + rng() * 0.35,
        phase: rng() * Math.PI * 2,
        freq: 0.6 + rng() * 1.8,
      });
    }
  }
  partsCache = parts;
  return parts;
}

export type V2 = [number, number];

// 8 directions, index 0 = toward -z (into the screen)
const DIRS: V2[] = [
  [0, -1],
  [Math.SQRT1_2, -Math.SQRT1_2],
  [1, 0],
  [Math.SQRT1_2, Math.SQRT1_2],
  [0, 1],
  [-Math.SQRT1_2, Math.SQRT1_2],
  [-1, 0],
  [-Math.SQRT1_2, -Math.SQRT1_2],
];

function walk(rng: () => number, start: V2, dir: number, segs: number, maxX = 30): V2[] {
  const pts: V2[] = [start];
  let d = dir;
  let [x, z] = start;
  for (let i = 0; i < segs; i++) {
    const diag = d % 2 === 1;
    const len = diag ? 1 + rng() * 2.5 : 2 + rng() * 9;
    const dv = DIRS[d]!;
    x += dv[0] * len;
    z += dv[1] * len;
    if (Math.abs(x) > maxX) {
      x = Math.sign(x) * maxX;
    }
    pts.push([x, z]);
    if (diag) {
      // after a 45° jog, settle back on an axis
      d = (d + (rng() < 0.5 ? 1 : 7)) % 8;
    } else if (rng() < 0.7) {
      d = (d + (rng() < 0.5 ? 1 : 7)) % 8;
    }
    if (z < BOARD.zEnd + 4 || z > BOARD.zStart - 2) break;
  }
  return pts;
}

function offsetPolyline(pts: V2[], offset: number): V2[] {
  const out: V2[] = [];
  for (let i = 0; i < pts.length; i++) {
    const prev = pts[i - 1];
    const cur = pts[i]!;
    const next = pts[i + 1];
    const n = (a: V2, b: V2): V2 => {
      const dx = b[0] - a[0];
      const dz = b[1] - a[1];
      const l = Math.hypot(dx, dz) || 1;
      return [-dz / l, dx / l];
    };
    if (!prev) {
      if (!next) {
        out.push(cur);
        continue;
      }
      const nn = n(cur, next);
      out.push([cur[0] + nn[0] * offset, cur[1] + nn[1] * offset]);
    } else if (!next) {
      const nn = n(prev, cur);
      out.push([cur[0] + nn[0] * offset, cur[1] + nn[1] * offset]);
    } else {
      const n1 = n(prev!, cur);
      const n2 = n(cur, next!);
      let mx = n1[0] + n2[0];
      let mz = n1[1] + n2[1];
      const ml = Math.hypot(mx, mz) || 1;
      mx /= ml;
      mz /= ml;
      const dot = mx * n1[0] + mz * n1[1] || 1;
      out.push([cur[0] + (mx * offset) / dot, cur[1] + (mz * offset) / dot]);
    }
  }
  return out;
}

let tracesCache: V2[][] | null = null;

export function getTraces(): V2[][] {
  if (tracesCache) return tracesCache;
  const rng = mulberry32(42);
  const traces: V2[][] = [];

  // Fan-out from the hero chip pins
  const half = HERO_CHIP.size / 2 + 0.45;
  for (let i = 0; i < 32; i++) {
    const side = i % 4;
    const t = -1.6 + ((i >> 2) / 7) * 3.2;
    let start: V2;
    let dir: number;
    if (side === 0) {
      start = [HERO_CHIP.x + t, HERO_CHIP.z - half];
      dir = 0;
    } else if (side === 1) {
      start = [HERO_CHIP.x + half, HERO_CHIP.z + t];
      dir = 2;
    } else if (side === 2) {
      start = [HERO_CHIP.x + t, HERO_CHIP.z + half];
      dir = 4;
    } else {
      start = [HERO_CHIP.x - half, HERO_CHIP.z + t];
      dir = 6;
    }
    const pts: V2[] = [start];
    const out = 0.8 + rng() * 1.5;
    const dv = DIRS[dir]!;
    const p1: V2 = [start[0] + dv[0] * out, start[1] + dv[1] * out];
    pts.push(p1);
    traces.push([...pts, ...walk(rng, p1, (dir + (rng() < 0.5 ? 1 : 7)) % 8, 6).slice(1)]);
  }

  // Long parallel buses running the full length of the board
  for (let b = 0; b < 5; b++) {
    const x0 = -22 + b * 11 + (rng() - 0.5) * 4;
    const center: V2[] = [[x0, BOARD.zStart - 2]];
    let [x, z] = center[0]!;
    while (z > BOARD.zEnd + 6) {
      z -= 10 + rng() * 22;
      center.push([x, z]);
      const jog = (rng() < 0.5 ? -1 : 1) * (1.5 + rng() * 3);
      const nx = Math.max(-28, Math.min(28, x + jog));
      z -= Math.abs(nx - x);
      x = nx;
      center.push([x, z]);
    }
    const lines = 5 + Math.floor(rng() * 4);
    for (let l = 0; l < lines; l++) {
      traces.push(offsetPolyline(center, (l - (lines - 1) / 2) * 0.42));
    }
  }

  // Scattered local traces
  for (let i = 0; i < 110; i++) {
    const start: V2 = [(rng() - 0.5) * 56, BOARD.zStart - 4 - rng() * (BOARD.zStart - BOARD.zEnd - 8)];
    traces.push(walk(rng, start, Math.floor(rng() * 8), 3 + Math.floor(rng() * 5), 29));
  }

  tracesCache = traces.filter((t) => t.length > 1);
  return tracesCache;
}
