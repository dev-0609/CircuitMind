import { useFrame } from "@react-three/fiber";
import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { ROLE_HEX, type PartType } from "@/lib/circuit-palette";
import { getParts, mulberry32, type Part } from "./layout";
import { live } from "./live";

type G = THREE.BufferGeometry;

function place(g: G, opts: { x?: number; y?: number; z?: number; rx?: number; ry?: number; rz?: number }) {
  const m = new THREE.Matrix4().compose(
    new THREE.Vector3(opts.x ?? 0, opts.y ?? 0, opts.z ?? 0),
    new THREE.Quaternion().setFromEuler(new THREE.Euler(opts.rx ?? 0, opts.ry ?? 0, opts.rz ?? 0)),
    new THREE.Vector3(1, 1, 1),
  );
  g.applyMatrix4(m);
  return g;
}

const merge = (gs: G[]) => {
  // strip to position/normal so every primitive merges cleanly
  const clean = gs.map((g) => {
    const n = g.index ? g.toNonIndexed() : g;
    for (const k of Object.keys(n.attributes)) if (k !== "position" && k !== "normal") n.deleteAttribute(k);
    return n;
  });
  return mergeGeometries(clean)!;
};

const cyl = (r: number, h: number, seg = 16) => new THREE.CylinderGeometry(r, r, h, seg);

/** Two-legged lead pair bent down to the board (axial parts lying along x). */
function axialLeads(halfSpan: number, y: number, inner: number) {
  return [
    place(cyl(0.03, halfSpan - inner, 6), { x: (halfSpan + inner) / 2, y, rz: Math.PI / 2 }),
    place(cyl(0.03, halfSpan - inner, 6), { x: -(halfSpan + inner) / 2, y, rz: Math.PI / 2 }),
    place(cyl(0.03, y, 6), { x: halfSpan, y: y / 2 }),
    place(cyl(0.03, y, 6), { x: -halfSpan, y: y / 2 }),
  ];
}

interface PartDef {
  body: G;
  bodyColor: string;
  bodyRough: number;
  bodyMetal: number;
  metal: G;
  glow: G;
  halo: number;
}

function buildDef(type: PartType): PartDef {
  switch (type) {
    case "resistor":
      return {
        body: merge([
          place(cyl(0.21, 0.75), { y: 0.34, rz: Math.PI / 2 }),
          place(cyl(0.26, 0.24), { x: 0.4, y: 0.34, rz: Math.PI / 2 }),
          place(cyl(0.26, 0.24), { x: -0.4, y: 0.34, rz: Math.PI / 2 }),
        ]),
        bodyColor: "#c9a57c",
        bodyRough: 0.55,
        bodyMetal: 0.05,
        metal: merge(axialLeads(0.95, 0.34, 0.52)),
        glow: merge([
          place(cyl(0.27, 0.07), { x: -0.4, y: 0.34, rz: Math.PI / 2 }),
          place(cyl(0.225, 0.08), { x: -0.12, y: 0.34, rz: Math.PI / 2 }),
          place(cyl(0.225, 0.08), { x: 0.08, y: 0.34, rz: Math.PI / 2 }),
          place(cyl(0.27, 0.07), { x: 0.42, y: 0.34, rz: Math.PI / 2 }),
        ]),
        halo: 2.6,
      };
    case "capacitor":
      return {
        body: place(cyl(0.42, 1.1, 24), { y: 0.62 }),
        bodyColor: "#16243b",
        bodyRough: 0.35,
        bodyMetal: 0.2,
        metal: merge([
          place(cyl(0.4, 0.03, 24), { y: 1.18 }),
          place(cyl(0.03, 0.08, 6), { x: 0.15, y: 0.04 }),
          place(cyl(0.03, 0.08, 6), { x: -0.15, y: 0.04 }),
          place(cyl(0.44, 0.08, 24), { y: 0.1 }),
        ]),
        glow: merge([
          place(new THREE.CylinderGeometry(0.43, 0.43, 0.95, 12, 1, true, -0.4, 0.8), { y: 0.64 }),
          place(new THREE.TorusGeometry(0.26, 0.025, 6, 24), { y: 1.2, rx: Math.PI / 2 }),
          place(new THREE.BoxGeometry(0.05, 0.01, 0.4), { y: 1.2, ry: Math.PI / 4 }),
          place(new THREE.BoxGeometry(0.05, 0.01, 0.4), { y: 1.2, ry: -Math.PI / 4 }),
        ]),
        halo: 2.6,
      };
    case "transistor":
      return {
        body: merge([
          place(new THREE.CylinderGeometry(0.3, 0.3, 0.7, 16, 1, false, 0, Math.PI), { y: 0.8 }),
          place(new THREE.BoxGeometry(0.02, 0.7, 0.6), { y: 0.8 }),
        ]),
        bodyColor: "#141618",
        bodyRough: 0.45,
        bodyMetal: 0.1,
        metal: merge([
          place(cyl(0.025, 0.46, 6), { x: 0.1, y: 0.23, z: -0.18 }),
          place(cyl(0.025, 0.46, 6), { x: 0.1, y: 0.23 }),
          place(cyl(0.025, 0.46, 6), { x: 0.1, y: 0.23, z: 0.18 }),
        ]),
        glow: merge([
          place(new THREE.BoxGeometry(0.012, 0.16, 0.42), { x: -0.012, y: 0.92 }),
          place(new THREE.TorusGeometry(0.31, 0.02, 6, 16, Math.PI), { y: 1.15, rx: Math.PI / 2, rz: -Math.PI / 2 }),
        ]),
        halo: 2.2,
      };
    case "diode":
      return {
        body: place(cyl(0.15, 0.6), { y: 0.22, rz: Math.PI / 2 }),
        bodyColor: "#0f0f10",
        bodyRough: 0.15,
        bodyMetal: 0.4,
        metal: merge(axialLeads(0.75, 0.22, 0.3)),
        glow: place(cyl(0.162, 0.09), { x: 0.2, y: 0.22, rz: Math.PI / 2 }),
        halo: 1.9,
      };
    case "led":
      return {
        body: place(cyl(0.27, 0.07, 20), { y: 0.42 }),
        bodyColor: "#d9dde0",
        bodyRough: 0.2,
        bodyMetal: 0.6,
        metal: merge([place(cyl(0.025, 0.42, 6), { x: 0.1, y: 0.21 }), place(cyl(0.025, 0.42, 6), { x: -0.1, y: 0.21 })]),
        glow: merge([
          place(cyl(0.23, 0.36, 20), { y: 0.62 }),
          place(new THREE.SphereGeometry(0.23, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2), { y: 0.8 }),
        ]),
        halo: 3.2,
      };
    case "inductor":
      return {
        body: place(new THREE.TorusGeometry(0.5, 0.21, 14, 40), { y: 0.22, rx: -Math.PI / 2 }),
        bodyColor: "#b8733a",
        bodyRough: 0.32,
        bodyMetal: 0.9,
        metal: place(cyl(0.3, 0.05, 20), { y: 0.03 }),
        glow: merge([
          place(new THREE.TorusGeometry(0.82, 0.022, 6, 48), { y: 0.06, rx: -Math.PI / 2 }),
          place(new THREE.TorusGeometry(0.5, 0.215, 4, 40, 0.5), { y: 0.22, rx: -Math.PI / 2 }),
          place(new THREE.TorusGeometry(0.5, 0.215, 4, 40, 0.5), { y: 0.22, rx: -Math.PI / 2, rz: Math.PI }),
        ]),
        halo: 3.4,
      };
    case "ic": {
      const pins: G[] = [];
      for (let i = 0; i < 7; i++) {
        const x = -0.78 + i * 0.26;
        pins.push(place(new THREE.BoxGeometry(0.1, 0.3, 0.06), { x, y: 0.17, z: 0.6 }));
        pins.push(place(new THREE.BoxGeometry(0.1, 0.3, 0.06), { x, y: 0.17, z: -0.6 }));
        pins.push(place(new THREE.BoxGeometry(0.1, 0.04, 0.16), { x, y: 0.32, z: 0.52 }));
        pins.push(place(new THREE.BoxGeometry(0.1, 0.04, 0.16), { x, y: 0.32, z: -0.52 }));
      }
      return {
        body: place(new THREE.BoxGeometry(2, 0.32, 1.05), { y: 0.36 }),
        bodyColor: "#121417",
        bodyRough: 0.55,
        bodyMetal: 0.1,
        metal: merge(pins),
        glow: merge([
          place(new THREE.BoxGeometry(0.7, 0.01, 0.36), { y: 0.525 }),
          place(cyl(0.07, 0.01, 12), { x: -0.8, y: 0.525, z: 0.3 }),
          place(new THREE.BoxGeometry(1.7, 0.01, 0.025), { y: 0.525, z: -0.38 }),
        ]),
        halo: 4,
      };
    }
  }
}

const TYPES: PartType[] = ["resistor", "capacitor", "transistor", "diode", "led", "inductor", "ic"];
const LED_COLORS = ["#ff3344", "#33ff77", "#ffd166", "#f4f8ff", "#2de2ff"].map((c) => new THREE.Color(c));
const FAULT = new THREE.Color("#ff2a1a");
const OK = new THREE.Color("#39ff88");

function hash(n: number) {
  const s = Math.sin(n * 127.1) * 43758.5453;
  return s - Math.floor(s);
}

function intensity(p: Part, t: number) {
  const w = t * p.freq + p.phase;
  switch (p.type) {
    case "resistor":
      return 1.5 + 0.9 * Math.sin(w);
    case "capacitor": {
      const c = (Math.sin(w * 0.8) * 0.5 + 0.5) ** 2;
      return 0.35 + 2.8 * c;
    }
    case "transistor":
      return Math.sin(w * 3) > 0.1 ? 3.2 : 0.25;
    case "inductor":
      return 1.3 + 1.1 * Math.sin(w * 1.6);
    case "diode":
      return Math.max(0.12, Math.sin(w * 2)) * 3.2;
    case "ic":
      return 0.5 + 2.8 * hash(Math.floor(t * 9 + p.phase * 17));
    case "led":
      return 2.6 + 0.3 * Math.sin(w * 4);
  }
}

const haloTexture = () => {
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const g = c.getContext("2d")!;
  const grad = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  grad.addColorStop(0, "rgba(255,255,255,0.9)");
  grad.addColorStop(0.35, "rgba(255,255,255,0.28)");
  grad.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
};

export function Parts() {
  const parts = useMemo(() => getParts(), []);
  const groups = useMemo(
    () =>
      TYPES.map((type) => ({
        type,
        def: buildDef(type),
        parts: parts.filter((p) => p.type === type),
        base: new THREE.Color(ROLE_HEX[type]),
      })),
    [parts],
  );
  const ledColors = useMemo(() => {
    const rng = mulberry32(11);
    return groups.find((g) => g.type === "led")!.parts.map(() => LED_COLORS[Math.floor(rng() * LED_COLORS.length)]!);
  }, [groups]);

  const metalMat = useMemo(() => new THREE.MeshStandardMaterial({ color: "#cfd3d8", metalness: 1, roughness: 0.28 }), []);
  const glowMat = useMemo(() => new THREE.MeshBasicMaterial({ toneMapped: false }), []);
  const haloMat = useMemo(
    () =>
      new THREE.MeshBasicMaterial({
        map: haloTexture(),
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        toneMapped: false,
      }),
    [],
  );
  const haloGeo = useMemo(() => new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2).translate(0, 0.012, 0), []);

  const meshRefs = useRef<Record<string, THREE.InstancedMesh | null>>({});
  const haloRef = useRef<THREE.InstancedMesh>(null);
  const tmp = useMemo(() => new THREE.Color(), []);

  useLayoutEffect(() => {
    const m = new THREE.Matrix4();
    const hm = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const up = new THREE.Vector3(0, 1, 0);
    let h = 0;
    for (const g of groups) {
      g.parts.forEach((p, i) => {
        q.setFromAxisAngle(up, p.rot);
        m.compose(new THREE.Vector3(p.x, 0, p.z), q, new THREE.Vector3(p.scale, p.scale, p.scale));
        for (const k of ["body", "metal", "glow"]) {
          const mesh = meshRefs.current[`${g.type}-${k}`];
          mesh?.setMatrixAt(i, m);
        }
        meshRefs.current[`${g.type}-glow`]?.setColorAt(i, g.base);
        const hs = g.def.halo * p.scale;
        hm.compose(new THREE.Vector3(p.x, 0, p.z), q, new THREE.Vector3(hs, 1, hs));
        haloRef.current?.setMatrixAt(h, hm);
        haloRef.current?.setColorAt(h, g.base);
        h++;
      });
      for (const k of ["body", "metal", "glow"]) {
        const mesh = meshRefs.current[`${g.type}-${k}`];
        if (mesh) mesh.instanceMatrix.needsUpdate = true;
      }
    }
    if (haloRef.current) haloRef.current.instanceMatrix.needsUpdate = true;
  }, [groups]);

  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    const halo = haloRef.current;
    const global = live.power * live.flicker;
    let h = 0;
    for (const g of groups) {
      const glow = meshRefs.current[`${g.type}-glow`];
      g.parts.forEach((p, i) => {
        let k = intensity(p, t) * global;
        if (g.type === "led") {
          tmp.copy(ledColors[i]!);
          if (live.fault > 0.02) {
            const blink = Math.sin(t * 10 + p.phase) > 0 ? 1 : 0.1;
            tmp.lerp(FAULT, live.fault);
            k *= 1 - live.fault + live.fault * blink;
          }
          if (live.repair > 0.02) tmp.lerp(OK, live.repair * 0.85);
        } else {
          tmp.copy(g.base);
          // under a fault some parts go dark, others spike
          if (live.fault > 0.02 && hash(i * 3.1 + Math.floor(t * 6)) < 0.15 * live.fault) k *= 2.2;
        }
        tmp.multiplyScalar(k);
        glow?.setColorAt(i, tmp);
        tmp.multiplyScalar(0.26);
        halo?.setColorAt(h++, tmp);
      });
      if (glow?.instanceColor) glow.instanceColor.needsUpdate = true;
    }
    if (halo?.instanceColor) halo.instanceColor.needsUpdate = true;
  });

  return (
    <group>
      {groups.map((g) => (
        <group key={g.type}>
          <instancedMesh
            ref={(r) => {
              meshRefs.current[`${g.type}-body`] = r;
            }}
            args={[g.def.body, undefined, g.parts.length]}
            frustumCulled={false}
          >
            <meshStandardMaterial color={g.def.bodyColor} roughness={g.def.bodyRough} metalness={g.def.bodyMetal} />
          </instancedMesh>
          <instancedMesh
            ref={(r) => {
              meshRefs.current[`${g.type}-metal`] = r;
            }}
            args={[g.def.metal, metalMat, g.parts.length]}
            frustumCulled={false}
          />
          <instancedMesh
            ref={(r) => {
              meshRefs.current[`${g.type}-glow`] = r;
            }}
            args={[g.def.glow, glowMat, g.parts.length]}
            frustumCulled={false}
          />
        </group>
      ))}
      <instancedMesh ref={haloRef} args={[haloGeo, haloMat, parts.length]} frustumCulled={false} />
    </group>
  );
}
