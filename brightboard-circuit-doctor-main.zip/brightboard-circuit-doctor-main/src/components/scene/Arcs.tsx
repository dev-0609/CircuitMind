import { Line } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import type { Line2, LineMaterial } from "three-stdlib";
import { getParts, HERO_CHIP, mulberry32 } from "./layout";
import { live } from "./live";

const N = 14;

function Arc({ a, b, seed }: { a: THREE.Vector3; b: THREE.Vector3; seed: number }) {
  const ref = useRef<Line2>(null);
  const st = useRef({ on: false, until: 0, next: 0.5 + seed * 2.3, tick: 0 });
  const initial = useMemo(() => Array.from({ length: N }, (_, i) => a.clone().lerp(b, i / (N - 1))), [a, b]);
  const buf = useMemo(() => new Float32Array(N * 3), []);
  const dir = useMemo(() => b.clone().sub(a), [a, b]);
  const perp = useMemo(() => new THREE.Vector3(-dir.z, 0, dir.x).normalize(), [dir]);

  useFrame(({ clock }) => {
    const line = ref.current;
    if (!line) return;
    const t = clock.elapsedTime;
    const s = st.current;
    const rate = 0.35 + live.fault * 4 + live.sim * 0.6;
    if (!s.on && t > s.next) {
      s.on = true;
      s.until = t + 0.12 + Math.random() * 0.35;
    }
    if (s.on && t > s.until) {
      s.on = false;
      s.next = t + (1.2 + Math.random() * 5) / rate;
    }
    line.visible = s.on && live.power > 0.4;
    if (!line.visible) return;
    if (t - s.tick > 0.045) {
      s.tick = t;
      const h = 0.5 + dir.length() * 0.25;
      for (let i = 0; i < N; i++) {
        const u = i / (N - 1);
        const env = Math.sin(u * Math.PI);
        const j = (Math.random() - 0.5) * 0.7 * env;
        buf[i * 3] = a.x + dir.x * u + perp.x * j;
        buf[i * 3 + 1] = a.y + dir.y * u + env * h + (Math.random() - 0.5) * 0.35 * env;
        buf[i * 3 + 2] = a.z + dir.z * u + perp.z * j;
      }
      line.geometry.setPositions(buf);
    }
    const mat = line.material as LineMaterial;
    const flash = 3 + Math.random() * 3;
    mat.color.copy(live.color).lerp(new THREE.Color(1, 1, 1), 0.3).multiplyScalar(flash);
  });

  return <Line ref={ref} points={initial} lineWidth={1.8} toneMapped={false} color="#ffffff" transparent />;
}

export function Arcs() {
  const arcs = useMemo(() => {
    const rng = mulberry32(5);
    const parts = getParts();
    const list: { a: THREE.Vector3; b: THREE.Vector3 }[] = [];
    // arcs jumping off the hero chip
    for (let i = 0; i < 4; i++) {
      const ang = (i / 4) * Math.PI * 2 + 0.6;
      list.push({
        a: new THREE.Vector3(HERO_CHIP.x, 0.6, HERO_CHIP.z),
        b: new THREE.Vector3(HERO_CHIP.x + Math.cos(ang) * 4.5, 0.2, HERO_CHIP.z + Math.sin(ang) * 4.5),
      });
    }
    // arcs between neighbouring components all along the board
    for (let i = 0; i < 400 && list.length < 26; i++) {
      const p = parts[Math.floor(rng() * parts.length)]!;
      const q = parts.find((o) => o !== p && Math.hypot(o.x - p.x, o.z - p.z) < 4.2 && Math.hypot(o.x - p.x, o.z - p.z) > 2);
      if (!q || Math.abs(p.z - (list[list.length - 1]?.a.z ?? 99)) < 5) continue;
      list.push({ a: new THREE.Vector3(p.x, 0.7, p.z), b: new THREE.Vector3(q.x, 0.7, q.z) });
    }
    return list;
  }, []);

  return (
    <group>
      {arcs.map((arc, i) => (
        <Arc key={i} a={arc.a} b={arc.b} seed={i} />
      ))}
    </group>
  );
}
