import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { useRef } from "react";
import { Button } from "@/components/ui/button";
import { ROLES } from "@/lib/circuit-palette";
import { cn } from "@/lib/utils";
import { LogoMark } from "./Chrome";

export function FinalSection() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end end"] });
  const burst = useTransform(scrollYProgress, [0, 1], [0.3, 1.5]);
  const burstO = useTransform(scrollYProgress, [0, 0.6, 1], [0, 0.5, 0.25]);
  const y = useTransform(scrollYProgress, [0, 0.6], [120, 0]);

  return (
    <section ref={ref} id="launch" data-section={6} className="relative min-h-[140vh]">
      <div className="sticky top-0 flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 py-24 text-center">
        <motion.div
          style={{ scale: burst, opacity: burstO }}
          className="pointer-events-none absolute top-1/2 left-1/2 size-[90vmin] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle,var(--electric)_0%,transparent_65%)] blur-2xl"
        />
        <motion.div style={{ y }} className="relative flex flex-col items-center">
          <h2 className="max-w-4xl font-display text-5xl leading-[1.02] font-semibold tracking-tight md:text-7xl">
            Design circuits that <span className="text-energy">heal themselves.</span>
          </h2>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <Button variant="energy" size="xl">
              Launch CircuitMind <ArrowRight />
            </Button>
            <Button variant="wire" size="xl" asChild>
              <a href="#top">Back to start</a>
            </Button>
          </div>

          <div className="mt-20 grid w-full max-w-4xl grid-cols-2 gap-3 md:grid-cols-3">
            {ROLES.map((r) => (
              <div key={r.type} className="glass-panel flex items-start gap-3 p-4 text-left">
                <span className={cn("mt-1.5 size-2.5 shrink-0 rounded-full glow-dot animate-pulse-glow", r.swatch)} />
                <div>
                  <div className="font-display text-sm font-semibold">{r.name}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{r.job}</div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        <footer className="absolute inset-x-0 bottom-6 flex items-center justify-center gap-2 font-mono text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
          <LogoMark className="size-5" /> CircuitMind
        </footer>
      </div>
    </section>
  );
}
