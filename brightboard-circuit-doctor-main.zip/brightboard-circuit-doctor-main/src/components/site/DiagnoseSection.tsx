import { motion, useMotionValueEvent, useTransform, type MotionValue } from "framer-motion";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { PinnedSection, SectionHeading } from "./PinnedSection";

const NODES = [
  { node: "VIN", expected: "5.00 V", measured: "5.00 V", ok: true },
  { node: "R1 · out", expected: "2.02 V", measured: "0.00 V", ok: false },
  { node: "D1 · anode", expected: "2.02 V", measured: "0.00 V", ok: false },
  { node: "I · loop", expected: "19.6 mA", measured: "0.0 mA", ok: false },
  { node: "GND", expected: "0.00 V", measured: "0.00 V", ok: true },
];

export function DiagnoseSection() {
  return <PinnedSection id="diagnose" index={4}>{(p) => <DiagInner p={p} />}</PinnedSection>;
}

function DiagInner({ p }: { p: MotionValue<number> }) {
  const [scanned, setScanned] = useState(-1);
  const [verdict, setVerdict] = useState(false);
  useMotionValueEvent(p, "change", (v) => {
    setScanned(Math.floor(((v - 0.12) / 0.6) * NODES.length) - 0);
    setVerdict(v > 0.8);
  });
  const scanTop = useTransform(p, [0.12, 0.72], ["0%", "100%"]);
  const panelO = useTransform(p, [0, 0.12], [0, 1]);
  const panelScale = useTransform(p, [0, 0.15], [0.92, 1]);

  return (
    <div className="mx-auto grid w-full max-w-6xl items-center gap-10 md:grid-cols-[0.9fr_1.1fr]">
      <SectionHeading
        step="04"
        kicker="Diagnose"
        tone="text-scan"
        title="Finds what's wrong."
        line="Simulation results are probed node by node to pinpoint the root cause."
      />
      <motion.div style={{ opacity: panelO, scale: panelScale }} className="glass-panel p-5 md:p-6">
        <div className="grid grid-cols-[1.2fr_1fr_1fr_auto] gap-x-4 px-3 pb-2 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
          <span>Node</span>
          <span>Expected</span>
          <span>Measured</span>
          <span />
        </div>
        <div className="relative">
          {NODES.map((n, i) => {
            const seen = i <= scanned;
            return (
              <div
                key={n.node}
                className={cn(
                  "grid grid-cols-[1.2fr_1fr_1fr_auto] items-center gap-x-4 rounded-md px-3 py-3 font-mono text-sm transition-all duration-300",
                  seen && !n.ok && "bg-fault/10",
                )}
              >
                <span className="text-foreground">{n.node}</span>
                <span className="text-muted-foreground">{n.expected}</span>
                <span className={cn("transition-colors", seen ? (n.ok ? "text-ok" : "text-fault") : "text-muted-foreground/40")}>
                  {seen ? n.measured : "—"}
                </span>
                <span className={cn("size-2 rounded-full", seen ? (n.ok ? "bg-ok glow-dot text-ok" : "bg-fault glow-dot text-fault") : "bg-muted")} />
              </div>
            );
          })}
          <motion.div style={{ top: scanTop }} className="pointer-events-none absolute inset-x-0 -mt-px">
            <div className="h-10 -translate-y-full bg-gradient-to-b from-transparent to-scan/20" />
            <div className="h-px bg-scan text-scan glow-dot" />
          </motion.div>
        </div>
        <div
          className={cn(
            "mt-4 flex items-center justify-between rounded-lg border px-4 py-3 font-mono text-sm transition-all duration-500",
            verdict ? "border-scan/50 bg-scan/10 opacity-100" : "border-border opacity-30",
          )}
        >
          <span>
            Root cause <span className="text-scan">→ R1 open circuit</span>
          </span>
          <span className="text-muted-foreground">97%</span>
        </div>
      </motion.div>
    </div>
  );
}
