import { motion, useMotionValueEvent, useTransform, type MotionValue } from "framer-motion";
import { Check } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { PinnedSection, SectionHeading } from "./PinnedSection";

const healthy = Array.from({ length: 201 }, (_, i) => {
  const v = 5 * (1 - Math.exp(-i / 28)) + (i > 90 ? Math.sin(i * 0.9) * 0.05 : 0);
  return `${i ? "L" : "M"}${i * 2} ${(180 - (v / 5) * 140).toFixed(1)}`;
}).join(" ");

const broken = Array.from({ length: 201 }, (_, i) => {
  let v = 5 * (1 - Math.exp(-i / 28));
  if (i > 70) v = Math.max(0, 5 * Math.exp(-(i - 70) / 6));
  return `${i ? "L" : "M"}${i * 2} ${(180 - (v / 5) * 140).toFixed(1)}`;
}).join(" ");

const STEPS = ["Replace R1 → 150 Ω", "Re-run ngspice", "All nodes within spec"];
const LEDS = 10;

export function RepairSection() {
  return <PinnedSection id="repair" index={5}>{(p) => <RepairInner p={p} />}</PinnedSection>;
}

function RepairInner({ p }: { p: MotionValue<number> }) {
  const [step, setStep] = useState(0);
  const [lit, setLit] = useState(0);
  useMotionValueEvent(p, "change", (v) => {
    setStep(v > 0.72 ? 3 : v > 0.48 ? 2 : v > 0.22 ? 1 : 0);
    setLit(Math.round(Math.min(1, Math.max(0, (v - 0.3) / 0.5)) * LEDS));
  });
  const brokenO = useTransform(p, [0.2, 0.45], [1, 0]);
  const heal = useTransform(p, [0.3, 0.75], [0, 1]);
  const panelY = useTransform(p, [0, 0.18], [-80, 0]);
  const panelO = useTransform(p, [0, 0.12], [0, 1]);

  return (
    <div className="mx-auto grid w-full max-w-6xl items-center gap-10 md:grid-cols-[0.9fr_1.1fr]">
      <SectionHeading
        step="05"
        kicker="Repair & verify"
        tone="text-ok"
        title="Fixed. Then proven."
        line="A corrective change is suggested and confirmed with a fresh simulation."
      />
      <motion.div style={{ y: panelY, opacity: panelO }} className="glass-panel p-5 md:p-6">
        <div className="relative aspect-[2/1] rounded-lg border border-ok/25 scope-grid">
          <svg viewBox="0 0 400 200" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" fill="none">
            <line x1="0" x2="400" y1="40" y2="40" className="stroke-ok/40" strokeDasharray="4 6" />
            <motion.path d={broken} className="stroke-fault" strokeWidth="2" style={{ opacity: brokenO }} strokeDasharray="5 5" />
            <motion.path d={healthy} className="stroke-ok" strokeWidth="2.5" style={{ pathLength: heal }} />
          </svg>
        </div>
        <ul className="mt-5 space-y-2.5">
          {STEPS.map((s, i) => (
            <li
              key={s}
              className={cn(
                "flex items-center gap-3 font-mono text-sm transition-all duration-500",
                i < step ? "text-foreground" : "text-muted-foreground/40",
              )}
            >
              <span
                className={cn(
                  "grid size-5 place-items-center rounded-full border transition-all duration-500",
                  i < step ? "border-ok bg-ok text-primary-foreground" : "border-border",
                )}
              >
                {i < step && <Check className="size-3" strokeWidth={3} />}
              </span>
              {s}
            </li>
          ))}
        </ul>
        <div className="mt-5 flex items-center gap-2">
          {Array.from({ length: LEDS }, (_, i) => (
            <span
              key={i}
              className={cn(
                "h-2 flex-1 rounded-full transition-all duration-300",
                i < lit ? "bg-ok text-ok glow-dot" : "bg-muted",
              )}
            />
          ))}
        </div>
      </motion.div>
    </div>
  );
}
