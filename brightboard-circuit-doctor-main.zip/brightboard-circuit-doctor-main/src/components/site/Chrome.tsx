import { AnimatePresence, motion, useScroll } from "framer-motion";
import { useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { ROLES } from "@/lib/circuit-palette";
import { SECTIONS, useSection } from "@/lib/circuit-store";
import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("size-7", className)} fill="none" aria-hidden>
      <rect x="8" y="8" width="16" height="16" rx="3" className="fill-background stroke-primary" strokeWidth="1.5" />
      <rect x="13" y="13" width="6" height="6" rx="1" className="fill-electric" />
      {[11, 16, 21].map((p) => (
        <g key={p} className="stroke-primary" strokeWidth="1.5" strokeLinecap="round">
          <path d={`M${p} 8V3`} />
          <path d={`M${p} 24v5`} />
          <path d={`M8 ${p}H3`} />
          <path d={`M24 ${p}h5`} />
        </g>
      ))}
    </svg>
  );
}

export function Nav() {
  return (
    <header className="fixed inset-x-0 top-0 z-40 flex items-center justify-between px-6 py-5 md:px-10">
      <a href="#top" className="flex items-center gap-2.5">
        <LogoMark />
        <span className="font-display text-sm font-semibold tracking-wide">CircuitMind</span>
      </a>
      <Button variant="wire" size="sm" className="rounded-full px-4" asChild>
        <a href="#launch">Launch</a>
      </Button>
    </header>
  );
}

const TONES = ["text-electric", "text-blueprint", "text-phosphor", "text-fault", "text-scan", "text-ok", "text-electric"];

/** Left-side progress rail drawn as a live trace with one node per section. */
export function ProgressRail() {
  const { scrollYProgress } = useScroll();
  const active = useSection();
  return (
    <nav aria-label="Sections" className="fixed top-1/2 left-8 z-40 hidden -translate-y-1/2 lg:block">
      <div className="relative flex flex-col gap-9 py-1">
        <div className="absolute top-0 bottom-0 left-[5px] w-px bg-border" />
        <motion.div
          className={cn("absolute top-0 bottom-0 left-[5px] w-px origin-top bg-current", TONES[active])}
          style={{ scaleY: scrollYProgress }}
        />
        {SECTIONS.map((s, i) => (
          <a key={s.id} href={`#${s.id}`} className="group relative flex items-center gap-3">
            <span
              className={cn(
                "relative z-10 size-[11px] rounded-full border transition-all duration-500",
                i <= active ? cn("border-current bg-current glow-dot", TONES[i]) : "border-muted-foreground/50 bg-background",
              )}
            />
            <span
              className={cn(
                "font-mono text-[10px] uppercase tracking-[0.25em] transition-all duration-300",
                "opacity-0 group-hover:opacity-80", i === active ? TONES[i] : "text-muted-foreground",
              )}
            >
              {s.label}
            </span>
          </a>
        ))}
      </div>
    </nav>
  );
}

/** Compact colour key so the glowing parts read as "doing their job". */
export function RoleLegend() {
  const section = useSection();
  return (
    <aside
      className={cn(
        "fixed right-6 bottom-6 z-30 hidden flex-col gap-1.5 rounded-xl glass-panel px-4 py-3 transition-opacity duration-500 xl:flex",
        section === 6 && "pointer-events-none opacity-0",
      )}
    >
      {ROLES.map((r) => (
        <div key={r.type} className="flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
          <span className={cn("size-1.5 rounded-full glow-dot animate-pulse-glow", r.swatch)} />
          {r.name}
        </div>
      ))}
    </aside>
  );
}

/** Full-screen transition burst — a different circuit effect for every section change. */
export function SurgeFlash() {
  const section = useSection();
  const first = useRef(true);
  useEffect(() => {
    const id = setTimeout(() => (first.current = false), 400);
    return () => clearTimeout(id);
  }, []);

  return (
    <div className="pointer-events-none fixed inset-0 z-30 overflow-hidden" aria-hidden>
      <AnimatePresence>{!first.current && <Burst key={section} section={section} />}</AnimatePresence>
    </div>
  );
}

function Burst({ section }: { section: number }) {
  const exit = { opacity: 0, transition: { duration: 0.2 } };
  switch (section) {
    case 1: // blueprint wipe
      return (
        <motion.div
          className="absolute inset-y-0 w-1/3 bp-lines opacity-60"
          initial={{ left: "-35%" }}
          animate={{ left: "110%" }}
          exit={exit}
          transition={{ duration: 1.1, ease: "easeInOut" }}
        />
      );
    case 2: // oscilloscope sweep
      return (
        <motion.svg
          viewBox="0 0 1200 120"
          preserveAspectRatio="none"
          className="absolute top-1/2 left-0 h-32 w-full -translate-y-1/2"
          initial={{ opacity: 1 }}
          animate={{ opacity: 0 }}
          exit={exit}
          transition={{ duration: 1.4, delay: 0.6 }}
        >
          <motion.path
            d={Array.from({ length: 121 }, (_, i) => `${i ? "L" : "M"}${i * 10} ${60 + Math.sin(i * 0.45) * 40 * Math.exp(-i / 90)}`).join(" ")}
            className="stroke-phosphor"
            strokeWidth="2.5"
            fill="none"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          />
        </motion.svg>
      );
    case 3: // short circuit: red strobe + glitch bars
      return (
        <motion.div className="absolute inset-0" exit={exit}>
          <motion.div
            className="absolute inset-0 bg-fault/30"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.9, 0, 0.6, 0, 0.35, 0] }}
            transition={{ duration: 0.9, times: [0, 0.08, 0.2, 0.3, 0.45, 0.6, 1] }}
          />
          {[18, 42, 67, 81].map((top, i) => (
            <motion.div
              key={top}
              className="absolute h-3 w-full bg-fault/50 mix-blend-screen"
              style={{ top: `${top}%` }}
              initial={{ x: "-100%" }}
              animate={{ x: ["-100%", "15%", "-30%", "100%"] }}
              transition={{ duration: 0.5, delay: i * 0.06 }}
            />
          ))}
        </motion.div>
      );
    case 4: // probe scan line
      return (
        <motion.div
          className="absolute inset-x-0 h-24 bg-gradient-to-b from-transparent to-scan/40"
          initial={{ top: "-10%" }}
          animate={{ top: "105%" }}
          exit={exit}
          transition={{ duration: 1.2, ease: "linear" }}
        >
          <div className="absolute bottom-0 h-px w-full bg-scan glow-dot text-scan" />
        </motion.div>
      );
    case 5: // repair ripple
      return (
        <motion.div
          className="absolute top-1/2 left-1/2 size-[40vmin] -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-ok text-ok glow-dot"
          initial={{ scale: 0.1, opacity: 1 }}
          animate={{ scale: 4, opacity: 0 }}
          exit={exit}
          transition={{ duration: 1.3, ease: "easeOut" }}
        />
      );
    case 6: // power surge
      return (
        <motion.div
          className="absolute inset-0 bg-[radial-gradient(circle_at_center,var(--electric)_0%,transparent_60%)]"
          initial={{ opacity: 0.55, scale: 0.6 }}
          animate={{ opacity: 0, scale: 1.6 }}
          exit={exit}
          transition={{ duration: 1.1, ease: "easeOut" }}
        />
      );
    default:
      return (
        <motion.div
          className="absolute inset-0 bg-electric/10"
          initial={{ opacity: 1 }}
          animate={{ opacity: 0 }}
          exit={exit}
          transition={{ duration: 0.8 }}
        />
      );
  }
}
