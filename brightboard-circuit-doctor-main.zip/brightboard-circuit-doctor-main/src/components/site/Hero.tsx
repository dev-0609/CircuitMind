import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { useRef } from "react";
import { Button } from "@/components/ui/button";

const WORD = "CircuitMind";

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, -160]);
  const opacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);
  const spacing = useTransform(scrollYProgress, [0, 1], ["-0.02em", "0.25em"]);
  const blur = useTransform(scrollYProgress, [0, 0.8], ["blur(0px)", "blur(10px)"]);

  return (
    <section ref={ref} id="top" data-section={0} className="relative h-[140vh]">
      <div className="sticky top-0 flex h-screen flex-col justify-center px-6 md:px-14 lg:pl-32">
        <motion.div style={{ y, opacity, filter: blur }} className="max-w-3xl">
          <div className="mb-6 flex items-center gap-3 font-mono text-xs uppercase tracking-[0.3em] text-electric animate-flicker-in">
            <span className="inline-block size-1.5 rounded-full bg-current glow-dot" />
            AI circuit engineer · ngspice verified
          </div>
          <motion.h1
            style={{ letterSpacing: spacing }}
            className="font-display text-5xl leading-[0.95] font-bold whitespace-nowrap sm:text-7xl md:text-8xl lg:text-[7.25rem]"
            aria-label={WORD}
          >
            {WORD.split("").map((c, i) => (
              <span
                key={i}
                aria-hidden
                className={i >= 7 ? "inline-block text-energy animate-flicker-in" : "inline-block text-glow animate-flicker-in"}
                style={{ animationDelay: `${0.15 + i * 0.07}s` }}
              >
                {c}
              </span>
            ))}
          </motion.h1>
          <p
            className="mt-7 max-w-lg text-lg text-muted-foreground md:text-xl animate-flicker-in"
            style={{ animationDelay: "1.1s" }}
          >
            Describe a circuit. Watch it simulate, break, and repair itself.
          </p>
          <div className="mt-10 flex flex-wrap gap-3 animate-flicker-in" style={{ animationDelay: "1.4s" }}>
            <Button variant="energy" size="xl" asChild>
              <a href="#launch">
                Start designing <ArrowRight />
              </a>
            </Button>
            <Button variant="wire" size="xl" asChild>
              <a href="#design">See the flow</a>
            </Button>
          </div>
        </motion.div>

        <motion.div style={{ opacity }} className="absolute bottom-10 left-6 flex items-center gap-4 md:left-14 lg:left-32">
          <svg width="2" height="56" className="overflow-visible" aria-hidden>
            <line x1="1" y1="0" x2="1" y2="56" className="stroke-border" strokeWidth="2" />
            <line x1="1" y1="0" x2="1" y2="56" className="stroke-electric animate-current" strokeWidth="2" strokeDasharray="6 34" />
          </svg>
          <span className="font-mono text-[11px] uppercase tracking-[0.3em] text-muted-foreground">Scroll to send current</span>
        </motion.div>
      </div>
    </section>
  );
}
