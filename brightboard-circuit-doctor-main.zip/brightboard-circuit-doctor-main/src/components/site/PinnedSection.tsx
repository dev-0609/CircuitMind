import { useScroll, type MotionValue } from "framer-motion";
import { useRef, type ReactNode } from "react";
import { cn } from "@/lib/utils";

/** A tall section whose content stays pinned while its own scroll progress (0→1) drives the animation. */
export function PinnedSection({
  id,
  index,
  className,
  children,
}: {
  id: string;
  index: number;
  className?: string;
  children: (progress: MotionValue<number>) => ReactNode;
}) {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  return (
    <section ref={ref} id={id} data-section={index} className={cn("relative h-[260vh]", className)}>
      <div className="sticky top-0 flex h-screen items-center overflow-hidden px-6 md:px-14 lg:pl-32 lg:pr-16">
        {children(scrollYProgress)}
      </div>
    </section>
  );
}

export function SectionHeading({
  step,
  kicker,
  title,
  line,
  tone,
  glitch,
}: {
  step: string;
  kicker: string;
  title: string;
  line: string;
  tone: string;
  glitch?: boolean;
}) {
  return (
    <div className="max-w-md">
      <div className={cn("mb-5 flex items-center gap-3 font-mono text-xs uppercase tracking-[0.3em]", tone)}>
        <span className="inline-block size-1.5 rounded-full bg-current glow-dot" />
        {step} — {kicker}
      </div>
      <h2
        data-text={title}
        className={cn(
          "font-display text-4xl leading-[1.05] font-semibold tracking-tight text-foreground md:text-6xl",
          glitch && "glitch",
        )}
      >
        {title}
      </h2>
      <p className="mt-5 text-base text-muted-foreground md:text-lg">{line}</p>
    </div>
  );
}

export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
export const range = (v: number, a: number, b: number) => clamp01((v - a) / (b - a));
