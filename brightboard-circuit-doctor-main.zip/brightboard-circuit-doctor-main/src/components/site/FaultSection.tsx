import { motion, useMotionValueEvent, useTransform, type MotionValue } from "framer-motion";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { PinnedSection, SectionHeading } from "./PinnedSection";

const FAULTS = [
  { part: "R1", kind: "Open circuit" },
  { part: "C1", kind: "Short to ground" },
  { part: "Q1", kind: "Gain drift −40%" },
];

const broken = Array.from({ length: 201 }, (_, i) => {
  const x = i * 2;
  let v = 5 * (1 - Math.exp(-i / 28));
  if (i > 70) v = Math.max(0, 5 * Math.exp(-(i - 70) / 6)) + (Math.sin(i * 7.3) * Math.sin(i * 1.7)) * 0.5;
  if (i > 120 && i % 17 < 2) v += 2.4;
  return `${i ? "L" : "M"}${x} ${(180 - (v / 5) * 140).toFixed(1)}`;
}).join(" ");

export function FaultSection() {
  return <PinnedSection id="fault" index={3}>{(p) => <FaultInner p={p} />}</PinnedSection>;
}

function FaultInner({ p }: { p: MotionValue<number> }) {
  const [count, setCount] = useState(0);
  useMotionValueEvent(p, "change", (v) => setCount(v > 0.62 ? 3 : v > 0.42 ? 2 : v > 0.22 ? 1 : 0));
  const draw = useTransform(p, [0.15, 0.8], [0, 1]);
  const panelO = useTransform(p, [0, 0.12], [0, 1]);
  const skew = useTransform(p, [0, 0.12, 0.2], [12, -4, 0]);

  return (
    <div className="mx-auto grid w-full max-w-6xl items-center gap-10 md:grid-cols-[0.9fr_1.1fr]">
      <SectionHeading
        step="03"
        kicker="Break"
        tone="text-fault"
        title="Faults, on purpose."
        line="Controlled failures are injected to see exactly how the circuit misbehaves."
        glitch
      />
      <motion.div style={{ opacity: panelO, skewX: skew }} className="glass-panel relative overflow-hidden p-5 md:p-6">
        <div className="pointer-events-none absolute inset-0 noise-lines" />
        <div className="relative">
          <div className="mb-4 flex flex-wrap gap-2">
            {FAULTS.map((f, i) => (
              <div
                key={f.part}
                className={cn(
                  "flex items-center gap-2 rounded-full border px-3 py-1.5 font-mono text-xs transition-all duration-300",
                  i < count ? "border-fault/60 bg-fault/15 text-foreground" : "border-border text-muted-foreground opacity-40",
                )}
              >
                <span className={cn("size-1.5 rounded-full bg-fault", i < count && "glow-dot text-fault animate-blink")} />
                <span className="text-fault">{f.part}</span> {f.kind}
              </div>
            ))}
          </div>
          <div className="relative aspect-[2/1] rounded-lg border border-fault/25 scope-grid">
            <svg viewBox="0 0 400 200" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" fill="none">
              <line x1="0" x2="400" y1="40" y2="40" className="stroke-phosphor/30" strokeDasharray="4 6" />
              <motion.path d={broken} className="stroke-fault" strokeWidth="2.5" style={{ pathLength: draw }} />
            </svg>
            {count > 0 && (
              <div className="absolute top-3 right-3 rounded bg-fault/20 px-2 py-1 font-mono text-[10px] uppercase tracking-[0.2em] text-fault animate-blink">
                Out of spec
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
