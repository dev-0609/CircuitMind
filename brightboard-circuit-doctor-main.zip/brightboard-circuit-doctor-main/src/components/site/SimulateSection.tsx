import { motion, useTransform, type MotionValue } from "framer-motion";
import { PinnedSection, SectionHeading } from "./PinnedSection";

const W = 400;
const H = 200;

const charge = Array.from({ length: 201 }, (_, i) => {
  const x = (i / 200) * W;
  const v = 5 * (1 - Math.exp(-i / 28)) + (i > 90 ? Math.sin(i * 0.9) * 0.06 : 0);
  return `${i ? "L" : "M"}${x.toFixed(1)} ${(H - 20 - (v / 5) * 140).toFixed(1)}`;
}).join(" ");

const current = Array.from({ length: 201 }, (_, i) => {
  const x = (i / 200) * W;
  const a = 20 * Math.exp(-i / 28);
  return `${i ? "L" : "M"}${x.toFixed(1)} ${(H - 20 - (a / 20) * 140 * 0.9).toFixed(1)}`;
}).join(" ");

export function SimulateSection() {
  return <PinnedSection id="simulate" index={2}>{(p) => <SimInner p={p} />}</PinnedSection>;
}

function SimInner({ p }: { p: MotionValue<number> }) {
  const draw = useTransform(p, [0.15, 0.75], [0, 1]);
  const beam = useTransform(p, [0.15, 0.75], ["0%", "100%"]);
  const vout = useTransform(p, [0.15, 0.75], [0, 4.98]);
  const amps = useTransform(p, [0.15, 0.75], [0, 19.6]);
  const voutText = useTransform(vout, (v) => v.toFixed(2));
  const ampsText = useTransform(amps, (v) => v.toFixed(1));
  const panelX = useTransform(p, [0, 0.18], [100, 0]);
  const panelO = useTransform(p, [0, 0.12], [0, 1]);

  return (
    <div className="mx-auto grid w-full max-w-6xl items-center gap-10 md:grid-cols-[0.9fr_1.1fr]">
      <SectionHeading
        step="02"
        kicker="Simulate"
        tone="text-phosphor"
        title="Proven in ngspice."
        line="Every design is run through a real circuit simulator before you trust it."
      />
      <motion.div style={{ x: panelX, opacity: panelO }} className="glass-panel overflow-hidden p-5 md:p-6">
        <div className="mb-3 flex items-center justify-between font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
          <span>.tran 1ms</span>
          <span className="flex items-center gap-2 text-phosphor">
            <span className="size-1.5 rounded-full bg-current glow-dot animate-pulse-glow" /> live
          </span>
        </div>
        <div className="relative aspect-[2/1] rounded-lg border border-phosphor/20 scope-grid">
          <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="absolute inset-0 h-full w-full" fill="none">
            <line x1="0" x2={W} y1="40" y2="40" className="stroke-phosphor/40" strokeDasharray="4 6" />
            <motion.path d={current} className="stroke-role-capacitor" strokeWidth="1.5" style={{ pathLength: draw }} opacity={0.7} />
            <motion.path d={charge} className="stroke-phosphor" strokeWidth="2.5" style={{ pathLength: draw }} />
          </svg>
          <motion.div style={{ left: beam }} className="absolute inset-y-0 w-px bg-phosphor text-phosphor glow-dot" />
        </div>
        <div className="mt-4 grid grid-cols-3 gap-3 font-mono">
          <Readout label="V out" unit="V" value={voutText} tone="text-phosphor" />
          <Readout label="I led" unit="mA" value={ampsText} tone="text-role-capacitor" />
          <div className="rounded-lg border border-border bg-background/40 px-3 py-2">
            <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Engine</div>
            <div className="text-sm text-foreground">ngspice</div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function Readout({ label, unit, value, tone }: { label: string; unit: string; value: MotionValue<string>; tone: string }) {
  return (
    <div className="rounded-lg border border-border bg-background/40 px-3 py-2">
      <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{label}</div>
      <div className={`text-lg tabular-nums ${tone}`}>
        <motion.span>{value}</motion.span>
        <span className="ml-1 text-xs text-muted-foreground">{unit}</span>
      </div>
    </div>
  );
}
