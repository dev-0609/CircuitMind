import { ClientOnly, createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense, useEffect } from "react";
import { Nav, ProgressRail, RoleLegend, SurgeFlash } from "@/components/site/Chrome";
import { DesignSection } from "@/components/site/DesignSection";
import { DiagnoseSection } from "@/components/site/DiagnoseSection";
import { FaultSection } from "@/components/site/FaultSection";
import { FinalSection } from "@/components/site/FinalSection";
import { Hero } from "@/components/site/Hero";
import { RepairSection } from "@/components/site/RepairSection";
import { SimulateSection } from "@/components/site/SimulateSection";
import { circuitState, setSection } from "@/lib/circuit-store";

const CircuitScene = lazy(() => import("@/components/scene/CircuitScene"));

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CircuitMind — AI circuit design, simulation & self-repair" },
      {
        name: "description",
        content:
          "Describe a circuit in plain language. CircuitMind designs it, verifies it in ngspice, injects faults, diagnoses them and proves the repair.",
      },
      { property: "og:title", content: "CircuitMind — AI circuit design, simulation & self-repair" },
      {
        property: "og:description",
        content: "AI-assisted circuit design with ngspice-verified simulation, fault diagnosis and repair.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function useScrollDriver() {
  useEffect(() => {
    const onScroll = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      circuitState.progress = max > 0 ? window.scrollY / max : 0;
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) setSection(Number((e.target as HTMLElement).dataset["section"]));
        }
      },
      { rootMargin: "-50% 0px -50% 0px" },
    );
    document.querySelectorAll<HTMLElement>("[data-section]").forEach((el) => io.observe(el));
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      io.disconnect();
    };
  }, []);
}

function Index() {
  useScrollDriver();
  return (
    <div className="relative">
      <div className="fixed inset-0 -z-0" aria-hidden>
        <ClientOnly fallback={null}>
          <Suspense fallback={null}>
            <CircuitScene />
          </Suspense>
        </ClientOnly>
      </div>
      <div className="pointer-events-none fixed inset-0 scrim-left" aria-hidden />
      <Nav />
      <ProgressRail />
      <RoleLegend />
      <SurgeFlash />
      <main className="relative z-10">
        <Hero />
        <DesignSection />
        <SimulateSection />
        <FaultSection />
        <DiagnoseSection />
        <RepairSection />
        <FinalSection />
      </main>
    </div>
  );
}
