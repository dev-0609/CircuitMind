# CircuitMind roadmap

## In progress — functional app (audit request, Oct 2026)
- [ ] Typed API client (health, simulate, fault-inject, diagnose, repair) with configurable base URL + timeout
- [ ] Explicit mock mode with labelled JSON fixtures; real mode never falls back to mock
- [ ] Circuit data model (electrical vs visual separated), catalog, templates, connectivity validation
- [ ] App shell: sidebar, top bar with backend/engine/save status, theme toggle
- [ ] Workspace: schematic canvas editor (add/move/rotate/wire/delete/undo/redo/zoom/fit/save)
- [ ] Property editor with units + validation; circuit targets editor
- [ ] Simulation panel + results dashboard + charts from returned measurements
- [ ] Fault injection, diagnosis, repair recommendation, repair verification, baseline/faulty/repaired comparison
- [ ] Overview, My Circuits, History, Fault Lab, Component Library, Docs, Settings pages
- [ ] Error handling: disconnection, timeout, validation, simulation error, failed verification
- [ ] Landing page: wire dead buttons, label illustrative values
- [ ] API contract doc + README + tests
