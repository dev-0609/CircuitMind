<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- The 3D background (src/components/scene) is loaded lazily inside `ClientOnly` on the index route; it must never be imported statically from SSR code — three.js/WebGL touch browser APIs.
- Scroll state flows one way: page sets `circuitState` (src/lib/circuit-store.ts), the scene reads it each frame via `live` (scene/live.ts) — never push per-frame values through React state.
- Repeated circuit parts, traces and pulses are drawn with instanced meshes to keep draw calls low; add new part types as another instanced group, not individual meshes.
- Role colours live in two synced places: hex in src/lib/circuit-palette.ts (3D) and `--role-*` tokens in src/styles.css (UI). Change both together.
- Each page section is a `PinnedSection` whose own scroll progress drives its panel animation; section-change bursts live in `SurgeFlash`.
